var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( 'CommunityPA Chat live_game_options_bar already loaded' );
        return;
    }

    paChatLoaded = true;

    console.log( 'Community Chat live_game_options_bar' );

    if ( ! handlers.uberbar_notification )
    {
        handlers.uberbar_notification = function( payload )
        {
            if ( model.uberBar() )
                return;

            $('#btn_uberbar').addClass('uberbar-notification');
        };

        model.uberBar.subscribe(function( uberBar )
        {
            if ( uberBar )
                $('#btn_uberbar').removeClass('uberbar-notification');
        });
    }
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}
