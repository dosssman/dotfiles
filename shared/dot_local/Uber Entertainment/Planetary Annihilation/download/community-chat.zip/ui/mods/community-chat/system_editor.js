var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( 'Community Chat system_editor already loaded' );
        return;
    }

    paChatLoaded = true;

    console.log( 'Community Chat system_editor' );

    model.disableStartingPlanetToggle = ko.computed(function () {
        return model.starting_planet() && (model.customLandingZoneCount() || api.terrain_editor.editingLandingZones());
    });

    ko.computed( function()
    {
       var state =
       {
           scene: 'system_editor',
           status: 'System Editor',
           timestamp: Date.now()
       }
       api.Panel.message( 'uberbar', 'community_chat_state', state );
    });
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}