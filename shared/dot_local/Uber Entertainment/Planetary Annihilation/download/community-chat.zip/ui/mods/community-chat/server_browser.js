var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( "Community Chat server_browser already loaded" );
        return;
    }

    paChatLoaded = true;

    console.log( "Community Chat server_browser" );

    if ( ! globalHandlers.view_contact_replays )
    {
        globalHandlers.view_contact_replays = function( payload )
        {

            if ( !payload.uberId )
                return false;

            var params = '?uberId=' + payload.uberId;

            if ( payload.displayName )
                params = params + '&displayName=' + encodeURIComponent(payload.displayName);

            window.location.href = 'coui://ui/main/game/replay_browser/replay_browser.html' + params;

            return true;
        }
    }

    ko.computed( function()
    {
        var titans = api.content.usingTitans();

        var status = titans ? 'Viewing games browser' : 'Viewing classic games browser';

        var state =
        {
            scene: 'server_browser',
            status: status,
            timestamp: Date.now()
        }

       api.Panel.message( 'uberbar', 'community_chat_state', state );
    });
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}