var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( 'Community Chat matchmaking already loaded' );
        return;
    }

    paChatLoaded = true;

    console.log( 'Community Chat matchmaking' );

    ko.computed( function()
    {
        try
        {
            var stateString = model.stateString();

            var timeInQueue = model.timeInQueue();

            api.game.isWindowFocused().then( function( focused )
            {
                var state =
                {
                    scene: 'matchmaking',
                    gameType: 'Ladder1v1',
                    state: stateString,
                    timeInQueue: timeInQueue,
                    status: 'Playing 1v1 Ranked',
                    focused: focused,
                    timestamp: Date.now()
                }

                api.Panel.message( 'uberbar', 'community_chat_state', state );
            });
        }

        catch ( e )
        {
            console.error( e );
        }

    }).extend(
    {
        rateLimit: 5000
    });
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}