var communityChatJabberLoaded;

if ( communityChatJabberLoaded )
{
    console.log( "Community Chat Jabber already loaded" );
}
else
{

    communityChatJabberLoaded = true;

    console.log( "Community Chat Jabber" );

    var jabber;

    var allowLogging = false; /* squelch logging by default */

    function log( object )
    {
        if ( allowLogging )
        {
console.log( object );
        }
    }

    function Jabberer( uber_id, jabber_token, use_ubernetdev, resource )
    {
        var self = this;

        var dev = $.url().param('dev') != undefined;

        var test = $.url().param('test') != undefined;

        if ( dev || test )
            resource = resource + '-' + Date.now();

        self.uberId = ko.observable().extend ({session: 'uberId'} );
        self.jabberToken = ko.observable().extend( {session: 'jabberToken'} );
        self.sid = ko.observable( '' ).extend( { session: 'jabberSid' } );
        self.rid = ko.observable( '' ).extend( { session: 'jabberRid' } );
        self.jid = ko.observable( '' ).extend( { session: 'jabberJid' } );
        self.resource = ko.observable( '' ).extend( { session: 'jabberResource' } );;

        if ( uber_id )
            self.uberId( uber_id );

        if ( jabber_token )
            self.jabberToken( jabber_token );

        if ( resource )
            self.resource( resource );

        var connection;

        var MAX_RETRIES = 10;
        var RETRY_TIMEOUT = 30; // seconds
        var connection_attempts = 0;

// palobby needs a disconnect method

        var stayDisconnected = false;

        var reconnectTimeout = false;

        self.getConnection = function()
        {
            return connection;
        }

        self.connected = function()
        {
            return connection && connection.connected;
        }

        self.disconnect = function( reason )
        {
            self.stayDisconnected = true;
            connection.options.sync = true;
            connection.disconnect( reason || '' );
            connection.flush();
        }

// palobby needs to know the connection status

        self.connected = function()
        {
            return connection && connection.connected;
        }

//

        self.useUbernetdev = ko.observable().extend({ session: 'use_ubernetdev' } );

        if ( use_ubernetdev )
            self.useUbernetdev( !! use_ubernetdev );

        var SERVICE_URL = 'xmpp.planetaryannihilation.net';

        var version = window.gVersion;

        if (self.useUbernetdev())
            SERVICE_URL = 'xmpp.dev.planetaryannihilation.net';

        self.roster = ko.observableArray();
        self.rosterMap = ko.computed( function()
        {
            var result = {};
            _.forEach( self.roster(), function( element )
            {
                result[ element ] = true;
            } );
            return result;
        } );

 // no longer used

        self.presenceType = ko.observable( 'available' );
        self.presenceStatus = ko.observable( '' );

//

        self.updatePresence = function( userInfo )
        {
            var userInfo = _.clone(userInfo);

            if (userInfo.clients)
                userInfo.clients = JSON.stringify(userInfo.clients);

            if (userInfo.resources)
                userInfo.resources = JSON.stringify(userInfo.resources);

            connection.send( $pres( _.clone( userInfo ) ) );
        };

// community chat needs some additional handlers

        var connectHandler;

        self.setConnectHandler = function( handler )
        {
            connectHandler = handler;

            if ( connection && connection.connected )
            {
                handler();
            }
        };

        var disconnectHandler;

        self.setDisconnectHandler = function( handler )
        {
            disconnectHandler = handler;
        };

        var paMsgHandler;
        var paPresenceHandler;
        var paCommandHandler;

        self.setMsgHandler = function( handler )
        {
            paMsgHandler = handler;
        }

        self.setPresenceHandler = function( handler )
        {
            paPresenceHandler = handler;
        }
        self.setCommandHandler = function( handler )
        {
            paCommandHandler = handler;
        }

        self.connectOrResume = function()
        {
console.log( Date().toLocaleString() + ' jabber connectOrResume' );

// palobby proxies via nginx due to same origin restrictions

            var scheme = SERVICE_URL.indexOf('uber') == -1 ? 'https://' : 'http://';

            var url = ( window.paLobby ? '': scheme + SERVICE_URL + ':5280' ) + '/http-bind';

//             url = 'ws://' + SERVICE_URL + ':5280/http-ws';

            var options =
            {
                keepalive: true
            };

            connection = new Strophe.Connection( url, options );
            connection.rawInput = rawInput;
            connection.rawOutput = rawOutput;

            var uberId = self.uberId();

            if ( ! uberId )
            {
console.error( Date().toLocaleString() + ' jabber missing uberId' );
                return;
            }

            var jid = UberidToJid( uberId ) + '/' + self.resource();

            self.jid( jid );

            if ( self.sid() )
            {
                try
                {
console.log( Date().toLocaleString() + ' jabber trying restore' );
                    connection.restore( jid, onConnect );
                    return;
                }
                catch( e )
                {

                }
            }

            var jabberToken = self.jabberToken();

            if ( ! jabberToken )
            {
console.log( Date().toLocaleString() + ' jabber missing jabberToken' );
                return;
            }

console.log( Date().toLocaleString() + ' jabber connect' );
            connection.connect( jid, jabberToken, onConnect );

        }

        self.saveSessionState = function()
        {
            if ( connection && connection.connected )
            {
                self.sid( connection._proto.sid );
                self.rid( connection._proto.rid );
            }
        }

        self.addContact = function( uberId )
        {

            if ( ! connection.connected )
                return;

console.log( 'jabber addContact ' + uberId );

            var jid = UberidToJid( uberId );

            var iq = $iq( { type: "set" } ).c( "query", { xmlns: "jabber:iq:roster" } ).c( "item", jid );

            connection.sendIQ( iq );

            connection.send( $pres( { to: jid, type: "subscribe" } ) );
        }

        self.removeContact = function( uberId )
        {
            if ( ! connection.connected )
                return;

console.log( 'jabber removeContact ' + uberId );

            var jid = UberidToJid( uberId );

            var iq = $iq( { type: "set" } ).c( "query", { xmlns: "jabber:iq:roster" } ).c( "item", { jid: jid, subscription: 'remove' } );

            connection.sendIQ( iq );

// xmpp server should send these but we will also send

            connection.send( $pres( { to: jid, type: "unsubscribe" } ) );
            connection.send( $pres( { to: jid, type: "unsubscribed" } ) );

            jabber.roster.remove( jid );
        }

        self.sendChat = function( uberId, message )
        {
            if ( !connection.connected || ! uberId || ! message )
                return;

            var jid = UberidToJid( uberId );
            var msg = $msg( { to: jid, type: 'chat' } ).c( 'body' ).t( message );
            connection.send( msg );
        }

        self.sendCommand = function( uberid, type, payload )
        {
            var jid = UberidToJid( uberid );
            var message = JSON.stringify( { message_type: type, payload: payload } );
log( message );
            connection.send( $msg( { to: jid, type: 'command' } ).c( 'body' ).t( message ) );
        }

        self.getRoster = function()
        {
            var iq = $iq( { type: 'get' } ).c( 'query', { xmlns: 'jabber:iq:roster' } );
            connection.sendIQ( iq );
        }

        function JidToUberid( jid )
        {
            return jid.split( '@' )[ 0 ];
        }

        function UberidToJid( uberid )
        {
            return uberid + '@' + SERVICE_URL;
        }

// community chat tracks multiple connections by resource

        function JidToResource( jid )
        {
            return Strophe.getResourceFromJid( jid );
        }

// community chat

        function connectedOrAttached()
        {
            connection_attempts = 0;

            if ( reconnectTimeout )
            {
                clearTimeout( reconnectTimeout );
                reconnectTimeout = false;
            }

            initHandlers();
            self.getRoster();

//             connection.send( $pres() );

            if ( connectHandler )
            {
                connectHandler();
            }

        }

        function onConnect( status )
        {

            switch ( status )
            {
                case Strophe.Status.CONNECTING:

console.log( 'jabber connecting' );

                    break;

                case Strophe.Status.CONNFAIL:

console.log( 'jabber connection failed' );

                    break;

                case Strophe.Status.DISCONNECTING:

console.log( 'jabber disconnecting' );

                    break;

                case Strophe.Status.DISCONNECTED:

console.log( 'jabber disconnected' );

// paLobby can disconnect

                    connection_attempts++;

                    if ( self.stayDisconnected || connection_attempts >= MAX_RETRIES )
                    {
                         self.jid( undefined );
                         self.sid( undefined );
                         self.rid( undefined );
                         self.stayDisconnected = true;
                    }

                    if ( disconnectHandler )
                        disconnectHandler( self.stayDisconnected, connection_attempts );

                    if ( ! self.stayDisconnected )
                    {

console.log( 'jabber reconnecting ' + connection_attempts );

                        if ( ! reconnectTimeout )
                            reconnectTimeout = setTimeout( self.connectOrResume, RETRY_TIMEOUT * 1000 );
                    }

                    break;

                case Strophe.Status.CONNECTED:

console.log( 'jabber connected' );

                    connectedOrAttached();

                    break;

                case Strophe.Status.ATTACHED:

console.log( 'jabber attached' );

                    connectedOrAttached();

                    break;

                case Strophe.Status.AUTHENTICATING:

console.log( 'jabber authenticating' );

                    break;

                case Strophe.Status.AUTHFAIL:

console.log( 'jabber authentication failed' );

                    break;

                case Strophe.Status.ERROR:

console.log( 'jabber error' );

                    break;

                default:

                    break;
            }
        }

        function initHandlers()
        {
            if ( connection && connection.connected )
            {
                connection.addHandler( onPresence, null, 'presence', null, null, null );
                connection.addHandler( onRoster, null, 'iq', null, null, null );
                connection.addHandler( onCommand, null, 'message', 'command', null, null );
                connection.addHandler( onMessage, null, 'message', 'chat', null, null );
                connection.addHandler( onMessageError, null, "message", 'error', null, null );
            }
        }

        function onPresence( message )
        {
            try
            {
                var type = $( message ).attr( 'type' );
                var from = $( message ).attr( 'from' );
                var to = $( message ).attr( 'to' );
                var status = $( message ).attr( 'status' ) || '';

log( message );

// review this

                var jid = Strophe.getBareJidFromJid( from );

                if ( ! jabber.rosterMap()[ jid ] )
                    jabber.roster.push( jid );

// handle subscribe and exit

                if ( type === 'subscribe' )
                {
// allow
                    connection.send( $iq( { type: "set" } ).c( "query", { xmlns: "jabber:iq:roster" } ).c( "item", from ) );

                    connection.send( $pres( { to: from, type: "subscribe" }));

                    connection.send( $pres( { to: from, type: 'subscribed' } ) );

// Block
// connection.send($pres({ to: from, "type": "unsubscribed" }));

                    return true;
                }

// ignore subscribed responses

                if ( type === 'subscribed' )
                    return true;

// after this point is presence updates

                var jid = from;
                var uberId = JidToUberid( jid );
                var resource = resource = JidToResource( jid );

                if ( uberId == self.uberId() && resource == self.resource() )
                    return true;

                if ( type == 'unavailable' )
                    status = '';

                if ( ! type )
                    type = 'available';

                if ( ! status )
                    status = '';

                var userInfo =
                {
                    type: type,
                    status: status
                };

                userInfo.league = message.getAttribute( "league" ) || undefined;
                userInfo.leaguePosition = message.getAttribute( "leaguePosition" ) || undefined;
                userInfo.lastMatchAt = message.getAttribute( "lastMatchAt" ) || undefined;
                userInfo.lastRankChange = message.getAttribute( "lastRankChange" ) || undefined;

                paPresenceHandler( uberId, jid, resource, userInfo );

                return true;
            }

            catch ( e )
            {

console.error( 'jabber onPrescence exception');
console.error( e );

                if ( window.paLobby && paLobby.dev )
                {
// debugger;
                }

                return true;
            }
        };

        function onRoster( message )
        {
console.log( 'onRoster' );
log(message);
            try
            {
                var type = $( message ).attr( 'type' );
                var from = $( message ).attr( 'from' );
                var to = $( message ).attr( 'to' );
                var xmlns = $( message ).attr( 'xmlns' );
                var id = $( message ).attr( 'id' );

                if ( message.firstChild )
                {
                    var items = message.firstChild.getElementsByTagName( 'item' );

                    var rosterMap = jabber.rosterMap();

                    for ( var i = 0; i < items.length; i++ )
                    {

                        var jid = items[ i ].getAttribute( 'jid' );
                        var name = items[ i ].getAttribute( 'name' );
                        var sub = items[ i ].getAttribute( 'subscription' );
                        var ask = items[ i ].getAttribute( 'ask' );

                        var found = rosterMap[ jid ];

                        if ( sub == 'remove' )
                        {
console.log( jid + ' removed from roster' );
                            jabber.roster.remove( jid );
                        }
                        else if ( ! found )
                            jabber.roster.push( jid );

                        if ( ask == 'subscribe' )
console.log( jid + ' pending ask' );

// log( '!!!   jid:' + jid + ' name:' + name + ' sub:' + sub + ' ask:' + ask );

                        connection.send( $pres( { to: jid, type: "probe" } ) );
                    }
                }

                if ( type === 'set' )
                {
                    var iq = $iq( { type: 'result', to: from, id: id } );
                    connection.sendIQ( iq );
                }
                return true;
            }

            catch ( e )
            {
console.error( 'jabber onRoster exception' );
console.error( e );
                return true;
            }
        };

        function onMessage( message )
        {

log( "jabber onMessageHandler" );
log( message );

            try
            {
                var from = message.getAttribute( 'from' );
                var to = message.getAttribute( 'to' );
                var type = message.getAttribute( 'type' );
                var body = message.getElementsByTagName( 'body' );

                from = JidToUberid( from );

                var content = '';

                if ( Strophe.getText( body[ 0 ] ) )
                    content = Strophe.getText( body[ 0 ] );

                paMsgHandler( from, htmlSpecialChars( content, true ) );
                return true;
            }

            catch ( e )
            {
console.log( 'jabber onMessage exception' );
console.log( e.stack || e );
                return true;
            }
        }

        function onMessageError( message )
        {

            try
            {
                var from = message.getAttribute( 'from' );
                var to = message.getAttribute( 'to' );
                var type = message.getAttribute( 'type' );
                var body = message.getElementsByTagName( 'body' );

                var stati = [];

                from = JidToUberid( from );

                jid = to;

                var errors = message.getElementsByTagName( "error" );

                if ( errors && errors.length > 0 )
                {
                    error = errors[ 0 ];

                    var errorCode = error.getAttribute( "code" ) || undefined;

                    if ( errorCode )
                        stati.push( errorCode );

                    var errorType = error.getAttribute( "type" ) || undefined;

                    if ( errorType )
                        stati.push( errorType );

                }

                var content = '';
                if ( Strophe.getText( body[ 0 ] ) )
                {
                    content = Strophe.getText( body[ 0 ] );
                }

console.log( 'jabber onMessageError ' + type + ' ' + from + ' to ' );
console.log( stati );
log(message);

                // TODO

                return true;
            }
            catch ( e )
            {
console.log( 'jabber onMessageError exception' );
console.log( e.stack || e );
                return true;
            }
        }

        function onCommand( message )
        {
            try
            {
                var from = message.getAttribute( 'from' );
                var to = message.getAttribute( 'to' );
                var type = message.getAttribute( 'type' );
                var body = message.getElementsByTagName( 'body' );

                var content = '';

                if ( Strophe.getText( body[ 0 ] ) )
                {
                    content = Strophe.getText( body[ 0 ] );
                }

                var command = JSON.parse( htmlSpecialChars( content, true ) );

console.log( 'jabber onCommand ' + command.message_type + ' ' + from + ' to ' + to);
console.log( message );

                paCommandHandler( JidToUberid( from ), command );

                return true;
            }

            catch ( e )
            {
                log( '!!!MESSAGE error:' + e );
                log( e.stack );
                return true;
            }
        }

        function rawInput( data )
        {
log( "JABBER RECEIVED: " + formatXml( data ) );
            self.saveSessionState();
        }

        function rawOutput( data )
        {
log( 'JABBER SENT: ' + formatXml( data ) );
            self.saveSessionState();
        }

// http://stackoverflow.com/questions/376373/pretty-printing-xml-with-javascript
        function formatXml( xml )
        {
            var formatted = '';
            var reg = /(>)(<)(\/*)/g;
            xml = xml.replace( reg, '$1\r\n$2$3' );
            var pad = 0;
            jQuery.each( xml.split( '\r\n' ), function( index, node )
            {
                var indent = 0;
                if ( node.match( /.+<\/\w[^>]*>$/ ) )
                {
                    indent = 0;
                }
                else if ( node.match( /^<\/\w/ ) )
                {
                    if ( pad != 0 )
                    {
                        pad -= 1;
                    }
                }
                else if ( node.match( /^<\w[^>]*[^\/]>.*$/ ) )
                {
                    indent = 1;
                }
                else
                {
                    indent = 0;
                }

                var padding = '';
                for ( var i = 0; i < pad; i++ )
                {
                    padding += '  ';
                }

                formatted += padding + node + '\r\n';
                pad += indent;
            } );

            return formatted;
        }
    }

    function initJabber( payload )
    {
console.log( 'initJabber' );

        if ( ! payload )
            payload = {};

        jabber = new Jabberer( payload.uber_id, payload.jabber_token, payload.use_ubernetdev, payload.resource );

        jabber.connectOrResume();
    }
}
