// !LOCNS:community_chat

var communityChatLoaded;

function communityChat()
{
    if ( communityChatLoaded )
    {
        console.log( "Commnuity Chat already loaded" );
        return;
    }

    communityChatLoaded = true;

    console.log( "Commnuity Chat uberbar" );

// environment

    model.PA = ! window.paLobby;

    model.client = 'PA';

    if ( window.paLobby )
    {
        model.client = paLobby.client;

        if ( paLobby.dev )
            model.client = model.client + '-DEV';
    }

    var dev = $.url().param('dev') != undefined;

    if ( dev )
        model.client = model.client + '-' + Date.now();

    delete localStorage[ 'info.nanodesu.pachat.disablechat' ];

    var modPath = 'coui://ui/mods/community-chat/';

    if ( ! model.PA )
        modPath = '/mods/community-chat/ui/mods/community-chat/';
    else if ( window.community_chat_dev )
        modPath = 'http://palobby.lan/mods/community-chat/ui/mods/community-chat/';

    var GLOBAL_ROOM_KEY = 'global';
    var TOURNAMENTS_ROOM_KEY = 'tournaments';

    var RANK_CHECK_INTERVAL = 5 * 60 * 1000;

    var TOURNAMENTS_CHECK_INTERVAL = 30 * 1000;

    var TOURNAMENTS_JOIN_TIME = 60*24; // 24 hours;
    var TOURNAMENTS_AUTOJOIN_START = 45; // 30 minutes
    var TOURNAMENTS_AUTOJOIN_FINISH = -30; // 30 minutes

    var TOURNAMENTS_TESTERS = [ '10952182184354445147', '15902732904735349906', '792369053434507164', '10717877472377876703', '14430282979781851477', '6550150456183863982', '13005412061495656253' ];

    var TOURNAMENTS_CASTERS = [ '8994388423356384837', '15132780807979906671', '18091841119231494036' ];

    var TITANS_EXPANSION = 'PAExpansion1';

    var chatDefaultOwnerColour = '#FF9900';
    var chatDefaultModeratorColour = '#3399FF';
    var chatDefaultMutedColour = '#606060';
    var chatDefaultBlockedColour = '#A0A0A0';
    var chatDefaultSelfColour = '#FF00CC';

    var chatDefaultSystemColour = '#00b3ff';
    var chatDefaultUberColour = '#eee';

    var chatDefaultTwitchColour = '#b063dc';

    var chatDefaultLadderColour = '#FF00CC';

    var chatRoomDefaultColour = '#00FF00';

    var chatDefaultMaxHeight = 0.5;
    var chatDefaultDesktopNotificationTimeout = 8;

    var chatDefaultMaxMessages = 1000;

    var chatDefaultSystemMessagesTimer = 1;
    var chatDefaultSystemMessagesExpiry = 10;

    var chatDefaultStatusMessagesTimer = 1;
    var chatDefaultStatusMessagesExpiry = 10;

    var chatDefaultHelpMessagesTimer = 1;
    var chatDefaultHelpMessagesExpiry = 10;

    ko.bindingHandlers.resizable = {
        init: function( element, valueAccessor )
        {
            var options = valueAccessor();
            $( element ).resizable( options );
        }
    };

// existing PA tooltip binding does not work for dynamic tooltips or removal

    ko.bindingHandlers.community_chat_tooltip = {
        init: function( element, valueAccessor, allBindingsAccessor, viewModel, bindingContext )
        {

            $( element ).tooltip(
            {
                false: true,
                delay:
                {
                    show: 0,
                    hide: 100
                },
                animation: 'fadeIn',
            } );

            ko.utils.domNodeDisposal.addDisposeCallback(element, function() {
                $( element ).tooltip( 'hide' );
            });

        },
        update: function( element, valueAccessor, allBindingsAccessor, viewModel, bindingContext )
        {

            var value = ko.utils.unwrapObservable( valueAccessor() );

            if ( _.isArray( value ) ) value = _.reduce( value, function( sum, val )
            {
                return sum + loc( val );
            }, '' );
            else value = loc( value );

// update the title directly

            var data = $( element ).data( 'bs.tooltip' );

            if ( data )
                data.options.title = value;
            else
                $( element ).tooltip( 'hide' );
        }
    };

    ko.extenders.communityChat_ubernet = function( target, option )
    {
        var base_key = option,
            ubernet_key = 'uberData.' + base_key,
            previous = {},
            timeout;

        var updateUbernetData = function( data )
        {

            timeout = undefined;

            if ( _.isUndefined( data ) || _.isNull( data ) )
                return;

            var payload =
            {
                Data: {}
            };

            payload.Data[ ubernet_key ] = data;

            var json = JSON.stringify( payload );

            if ( json === previous[ ubernet_key ] )
            {
                return;
            }

            console.log( Date().toLocaleString() + ' communityChat_ubernet.updateUserCustomData ' + ubernet_key + ' ' + _.size( json ) );

            if ( model.PA )
            {
                api.net.ubernet( '/GameClient/UpdateUserCustomData', 'POST', 'text', json ).done( function()
                {
                    previous[ ubernet_key ] = json;
                } ).fail( function( error )
                {
                    console.log( error );
                    console.log( 'failed to save ubernet data: ' + base_key );
                } );
            }

            localStorage.setItem( base_key, encode( data ) );

/* fallback to localstorage */

        };

        target.subscribe( function( value )
        {
            if ( timeout )
            {
                clearTimeout( timeout );
            }
            timeout = setTimeout( updateUbernetData, 1000, value );
        } );

        target.refresh = function()
        {
            var data = JSON.stringify( [ ubernet_key ] );

            var deferred = api.net.ubernet( '/GameClient/GetUserCustomData', 'GET', 'text', data ).done( function( data )
            {
                try
                {

                    var result = JSON.parse( data ).Data[ ubernet_key ];

                    var invalid = _.isUndefined( result ) || _.isNull( result );

                    if ( invalid ) /* fallback to localstorage */
                        result = decode( localStorage[ base_key ] );

                    if ( _.isUndefined( result ) || _.isNull( result ) )
                    {
                        throw ( 'no ubernet data' );
                    }
                    else
                    {
                        if ( invalid )
                        {
                            updateUbernetData( result );
                        }
                        else
                        {
                            var payload = {
                                Data:
                                {}
                            };
                            payload.Data[ ubernet_key ] = result;
                            previous[ ubernet_key ] = JSON.stringify( payload );
                        }
                        /* replicate local data to PlayFab */
                        target( result );
                    }


                }
                catch ( error )
                {
                    console.log( error );
                    console.log( 'malformed ubernet data: ' + base_key );
                }
            } ).fail( function( error )
            {
                console.log( error );
                console.log( 'failed to load ubernet data: ' + base_key );

                var result = decode( localStorage[ base_key ] );

                if ( !_.isUndefined( result ) && !_.isNull( result ) )
                {
                    updateUbernetData( result );
                    /* replicate local data to PlayFab */
                    target( result );
                }
            } );

            return deferred;
        };

        return target;
    };

// settings

    model.disableAutoJoinChat = ko.observable( false ).extend( { local: 'community-chat.disable-auto-join' } );

    model.toggledAutoJoinChat = function()
    {
        model.disableAutoJoinChat( ! model.disableAutoJoinChat() );
    }

    model.chatRoomOwnerColour = ko.observable( chatDefaultOwnerColour ).extend( { local: 'community-chat.owner-colour' } );

    model.chatRoomModeratorColour = ko.observable( chatDefaultModeratorColour ).extend( { local: 'community-chat.moderator-colour' } );

    model.chatRoomBlockedColour = ko.observable( chatDefaultBlockedColour ).extend( { local: 'community-chat.blocked-colour' } );

    model.chatRoomMutedColour = ko.observable( chatDefaultMutedColour ).extend( { local: 'community-chat.muted-colour' } );

    model.chatRoomSelfColour = ko.observable( chatDefaultSelfColour ).extend( { local: 'community-chat.self-colour' } );

    model.chatRoomUberColour = ko.observable( chatDefaultUberColour ).extend( { local: 'community-chat.uber-colour' } );

    model.chatRoomSystemColour = ko.observable( chatDefaultSystemColour ).extend( { local: 'community-chat.system-colour' } );

    model.chatRoomTwitchColour = ko.observable( chatDefaultTwitchColour ).extend( { local: 'community-chat.twitch-colour' } );

    model.chatRoomLadderColour = ko.observable( chatDefaultLadderColour ).extend( { local: 'community-chat.ladder-colour' } );

    model.chatRoomSelfColourSetting = ko.observable( model.chatRoomSelfColour() );

    model.chatRoomSelfColourSetting.subscribe( function( chatRoomSelfColour )
    {
        if ( ! new RegExp( /^#[0-9a-f]{6}$/i ).test( chatRoomSelfColour ) )
            return;

        model.chatRoomSelfColour( chatRoomSelfColour );

        var uberId = model.uberId();

        _.forEach( model.chatRoomMap(), function( room, roomKey )
        {
            _.forEach( room.sortedMessages(), function( messageObservable )
            {
                var message = messageObservable();

                if ( message.uberId == uberId )
                {
                    message.nameColour = chatRoomSelfColour;
                    messageObservable.valueHasMutated();
                }
            });
        })
    });

    model.chatRoomDefaultColour = ko.observable( chatRoomDefaultColour ).extend( { local: 'com.pa.chat.colour.other' } );

    model.maxHeight = ko.observable( chatDefaultMaxHeight ).extend( { local: 'community-chat-max-height' } );

    model.maxHeightCss = ko.computed( function()
    {
        return model.maxHeight() * 100 + '%';
    });

    model.alignChatLeft = ko.observable( false ).extend( { local: 'coma.pa.chat.alignLeft' } );

    model.paStatsIds = ko.observable( {} ).extend( { local: 'com.pa.chat.paStatsIds' } );

    model.activeTournamentPlayer = ko.observable( false );

// current user will be created during init

    model.user = ko.observable( false );

// push any display name changes into user

    model.displayName.subscribe( function( displayName )
    {
        var user = model.user();

        if ( user )
            user.displayName( displayName );
    });

    model.resetChatRoomColours = function()
    {
        model.chatRoomOwnerColour( chatDefaultOwnerColour );
        model.chatRoomModeratorColour( chatDefaultModeratorColour );
        model.chatRoomBlockedColour( chatDefaultBlockedColour );
        model.chatRoomMutedColour( chatDefaultMutedColour );
        model.chatRoomSelfColour( chatDefaultSelfColour );

        model.chatRoomTwitchColour( chatDefaultTwtichColour );
        model.chatRoomLadderColour( chatDefaultLadderColour );

        model.chatRoomUberColour( chatDefaultUberColour );
        model.chatRoomSystemColour( chatDefaultSystemColour );

        model.chatRoomDefaultColour( chatRoomDefaultColour );
    }

    model.paLobby_locale = decode( localStorage.locale );

    if ( ! window.MatchmakingUtility )
        loadScript( 'coui://ui/main/shared/js/matchmaking_utility.js' );

// links and url handling

    model.splitURLs = function( message )
    {
        var parts = [];

        _.forEach( message.split( /(\bhttps?:\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig ), function( part )
        {
            if ( part.trim() )
            {
                parts.push(
                {
                    text: part,
                    link: part.slice( 0, 7 ) == 'http://' || part.slice( 0, 8 ) == 'https://'
                } );
            }
        } );

        return parts;
    }

    model.openUrl = function( url )
    {
        if ( ! model.PA )
            return !url.substr( 0, 8 ) == 'https://' || !!window.open( url, '_blank' );

        engine.call( 'web.launchPage', url );
        return undefined;
    }

    model.getPaStatsIdAndOpen = function( uberId, url, description )
    {
        var paStatsId = model.paStatsIds()[ uberId ];

        if ( paStatsId )
            model.openUrl( url + paStatsId, description );
        else
        {
            engine.asyncCall( 'ubernet.call', '/GameClient/UserName?UberId=' + uberId, false ).done( function( data )
            {
                var result = JSON.parse( data );

                var pastatsprofilelink = ( window.paLobby ? 'https://palobby.com/pastatsplayerid' : 'http://pastats.com/report/getplayerid' ) + '?ubername=' + result.UberName;

                $.get( pastatsprofilelink, function( data )
                {
                    paStatsId = parseInt( data, 10 );

                    if ( paStatsId != -1 )
                    {
                        model.paStatsIds()[ uberId ] = paStatsId;
                        model.openUrl( url + paStatsId, description );
                    }
                    else
                        model.sendPrivateMessage( 'PA Stats ID could not be found or queried at this time. Please try again later' );
                } );
            } ).fail( function()
            {
                model.sendPrivateMessage( 'Ubername for PA Stats ID could not be queried at this time. Please try again later' );
            } );
        }
    };

    model.getRankDeferred = false;

    model.getRank = function()
    {
        console.log('getRank');

// if not conencted nothing we can do
        if ( ! window.jabber )
            return $.Deferred().reject();

        var deferred = model.getRankDeferred;

// if already in prgoress don't start another request

        if ( deferred && deferred.state() == 'pending' )
            return deferred;

        var titansGameMode = TITANS_EXPANSION + ':Ladder1v1';

        var deferred = model.getRankDeferred = $.Deferred();

        $.getJSON( 'https://api.planetaryannihilation.net/leaderboard/player?GameType=' + titansGameMode + '&UserId=' + model.uberId(), 'GET', 'json' ).done( function( data )
        {
            try
            {
                var user = model.user();

                user.league( data.League );
                user.leaguePosition( data.LeaguePosition );
                user.lastMatchAt( data.LastMatchAt );
                user.lastRankChange( data.LastRankChange );
                user.rankedGameCount( data.GameCount );
            }
            catch ( e )
            {
                console.error( "failed to prcocess titans player rank data" );
                console.error( e.stack || e );
            }

        } ).fail( function( jqXHR, textStatus, errorThrown )
        {
            console.error( "failed to get titans player rank" );
            console.error( textStatus );
        } ).always( function()
        {
            deferred.resolve();

            model.setupRankTimer();
        });;

        return deferred;
    }

    model.rankTimer = false;

    model.clearRankTimer = function()
    {
        if (model.rankTimer)
            clearInterval(model.rankTimer);
    }

    model.setupRankTimer = function()
    {
        if (model.rankTimer)
            clearInterval(model.rankTimer);

        model.rankTimer = setInterval(model.getRank, RANK_CHECK_INTERVAL);
    }

    model.leagueImage = function( isAdmin, isUber, league )
    {
        if ( isAdmin || isUber)
            return ( model.PA ? 'coui://ui/mods/community-chat/' : 'https://cdn.palobby.com/img/' ) + ( isAdmin ? 'admin.png' : 'vip.png' );

        return MatchmakingUtility.getSmallBadgeURL(league);
    }

    model.leagueImageOpacity = function( inactiveDays )
    {
        return Math.max( 0.4, Math.min( 1, 1 - inactiveDays / 14 ) );
    }

    model.leagueInactiveDays = function( lastMatchAt )
    {
        if ( ! lastMatchAt )
            return undefined;

        var last = Date.parse( lastMatchAt );

        if ( ! last )
            return undefined;

        var inactive = ( Date.now() - last - 14 * 24 * 60 * 60 * 1000 ) / ( 24 * 60 * 60 * 1000 );

        return inactive;
    }

    model.ladderText = function( league, position, inactiveDays )
    {
        if ( ! league || league == 'unranked' )
            return 'Unranked';

        if ( league > 0 && position > 0 )
            return '#' + position + ' ' + loc( '__rank_title__ Rank', { rank_title: MatchmakingUtility.getTitle( league ) } );

        if ( inactiveDays > 1 )
            return loc( 'Inactive for __inactive_days__ days', { inactive_days: Math.floor( inactiveDays ) } );

        return loc( 'Inactive' );
    }

    model.muteExpiryText = function( muted )
    {
        var display = muted ? 'muted' : '';

        if ( _.isNumber( muted ) )
        {
            var delta = muted - Date.now();

            if ( delta > 0 )
                display = display + ' until ' + model.formatTime( muted, false, delta >= 12 * 60 * 60 * 1000 );
        }

        return display;
    }

    model.resolvePresenceTypes = function( presenceTypes )
    {
        if ( presenceTypes.length == 0 )
            return 'unavailable';

        if ( presenceTypes.length == 1 )
            return presenceTypes[ 0 ];

        var presenceMap = {
            unavailable: 1,
            dnd: 2,
            away: 3,
            available: 4,
            'undefined': 5 // just in case
        }

// busy is first
        presenceTypes.sort( function( a, b )
        {
            a = presenceMap[ a ] || 99;
            b = presenceMap[ b ] || 99;

            if ( a < b )
                return -1;

            if ( a > b )
                return 1;

            return 0;
        } );

        return presenceTypes[ 0 ];
    }

    model.resolvePresenceStatuses = function( presenceStatuses )
    {

        if ( presenceStatuses.length == 0 )
            return '';

        if ( presenceStatuses.length > 1 )
            presenceStatuses = _.filter( presenceStatuses, function( status ) { return ! _.isEmpty( status ) } );

// use last non empty status for now

        return presenceStatuses.pop();
    }

    model.nameColour = function( isSelf, role, blocked, muted, displayName )
    {
        var nameColour = model.chatRoomDefaultColour();

        if (role == 'system' )
        {
            switch(displayName)
            {
                case 'twitch':
                    nameColour = model.chatRoomTwitchColour();
                    break;
                case 'ladder':
                    nameColour = model.chatRoomLadderColour();
                    break;
                default:
                    nameColor = model.chatRoomSystemColour();
            }
        }
        else if (role == 'twitch' )
            nameColour = model.chatRoomTwitchColour();
        else if ( isSelf )
            nameColour = model.chatRoomSelfColour();
        else if (role == 'uber')
            nameColour = model.chatRoomUberColour();
        else if (role == 'owner')
            nameColour = model.chatRoomOwnerColour();
        else if (role == 'moderator')
            nameColour = model.chatRoomModeratorColour();
        else if ( blocked )
            nameColour = model.chatRoomBlockedColour();
        else if ( role == 'muted' || muted )
            nameColour = model.chatRoomMutedColour();

        return nameColour;
    }

    model.messageLinkClick = function()
    {
        var part = this;
        model.openUrl( part.text );
    }

    model.linkClick = function( data, event )
    {
        var url = event.target.href;

        if (!url)
            return;

        if (url == 'help')
            model.showHelp();
        else
           model.openUrl( url);
    }

// chat room

    model.joinChannelName = ko.observable( '' );

    model.leaveRoom = function( roomKey )
    {
        CommunityChat.leave( roomKey );

        var room = model.chatRoomMap()[ roomKey ];

        delete model.chatRoomMap()[ roomKey ];

        model.chatRoomMap.valueHasMutated()
    }

// safer version

    model.deferredFixFriends = function()
    {
        _.delay( function() {model.fixFriends() }, 500 );
    }

    model.fixFriends = function()
    {
        var myUberId = model.uberId();

        _.forEach( jabber.roster(), function( jid )
        {
            var uberId = jid.split( '@' )[ 0 ];

            if ( uberId != myUberId )
            {

console.log( 'fixing ' + uberId );

                model.maybeCreateNewContactWithId( uberId );
                model.addUserTags( uberId, [ 'FRIEND' ] );
            }
        } )
    };

// ExtendedUserViewModel

// from uberbar.js with extensions for rank and league
// an ubernet user you have encountered: includes friends, recent contacts, ignored, blocked

    model.ExtendedUserViewModel = function( uberId, test )
    {
        var self = this;

        self.test = ko.observable( test );

        self.uberId = ko.observable( uberId );

        self.isSelf = uberId == model.uberId();

        self.isSpecial = ko.observable( undefined );
        self.isAdmin = ko.observable( undefined );
        self.isUber = ko.observable( undefined );

        self.rankedGameCount = ko.observable( undefined );

        self.leaguePosition = ko.observable( undefined );

        self.league = ko.observable( undefined );

        self.leagueImage = ko.computed( function()
        {
            return model.leagueImage( self.isAdmin(), self.isUber(), self.league() );
        });

        self.hasLeagueImage = ko.computed( function()
        {
            return ! _.isEmpty( self.leagueImage() );
        });

        self.lastMatchAt = ko.observable( undefined );
        self.lastRankChange = ko.observable( undefined );

        self.leagueInactiveDays = ko.computed( function()
        {
            return model.leagueInactiveDays( self.lastMatchAt() );
        });

        self.leagueImageOpacity = ko.computed( function()
        {
            return self.isSpecial() ? 1.0 : model.leagueImageOpacity( self.leagueInactiveDays() );
        });

        self.clientsMap = ko.observable( {} );

        self.resourcesMap = ko.observable( {} );

        self.loginCount = ko.computed( function()
        {
            return _.size( self.clientsMap() );
        });

        self.noPA = ko.computed( function()
        {
            var resourcesMap = self.resourcesMap();

            return ! resourcesMap.PA && _.size( resourcesMap) > 0;
        });

        self.hasWeb = ko.computed( function()
        {
            return self.resourcesMap().WEB;
        });

        self.isWeb = ko.computed( function()
        {
            var resourcesMap = self.resourcesMap();

            return resourcesMap.WEB && _.size( resourcesMap ) == 1;
        });

        self.displayName = ko.observable('');

// requestUserName is required by update_display_name

        self.requestUserName = function()
        {

            var id = self.test() || self.uberId();

            LeaderboardUtility.getPlayerDisplayName(id).subscribe(function(displayName)
            {
                self.displayName(displayName);

// update users display name

                if ( self.uberId() == model.uberId() )
                    model.displayName( displayName );

            });
        }

        if ( ! self.updateDisplayName )
        {
            self.updateDisplayName = function( payload )
            {
                if (payload && payload.displayName)
                    self.displayName(payload.displayName);
                else
                    self.requestUsername();
            }
        }

// set users display name as already known

        if ( self.isSelf )
            self.displayName( model.displayName() );
        else
            self.requestUserName();

        self.presenceType = ko.computed( function()
        {
            var type = model.resolvePresenceTypes( _.pluck( self.resourcesMap(), 'type' ) );

            var existing = model.idToJabberPresenceTypeMap()[ self.uberId() ];

            if ( existing != type )
            {
                model.idToJabberPresenceTypeMap()[ uberId ] = type;
                model.idToJabberPresenceTypeMap.valueHasMutated();
            }

            return type || 'unavailable';
        });

        self.status = ko.computed( function()
        {
             var resourcesMap = self.resourcesMap();

// PA status always overrides

            var paResource = resourcesMap[ 'PA' ];

            var status = paResource && paResource.status;

            if ( ! status )
                status = model.resolvePresenceStatuses( _.pluck( resourcesMap, 'status' ) );

            if ( ! status )
                status = '';

            var existing = model.idToJabberPresenceStatusMap()[ self.uberId() ];

            if ( existing != status )
            {
                model.idToJabberPresenceStatusMap()[ uberId ] = status;
                model.idToJabberPresenceStatusMap.valueHasMutated();
            }

            return status;
        });

        self.ladderText = ko.computed( function()
        {
            return self.isSpecial() ? '' : model.ladderText( self.league(), self.leaguePosition(), self.leagueInactiveDays() );
        });

        self.displayInfo = ko.computed( function()
        {
            var name = self.displayName();

            var info;

            if ( self.isSpecial() )
                info = 'DEV ';
            else
                info = self.ladderText() + ' ';

            info = info + name;

            var resourcesMap = self.resourcesMap();

            if ( _.size( resourcesMap ) > 0 )
            {
                info = info + ' (' + _.keys( resourcesMap ).join( ' / ' ) + ')';
            }

            return info;
        });

        self.tooltip = ko.computed( function()
        {
            var tooltip = self.displayInfo();

            var status = self.status();

            // if ( status )
            //     tooltip = tooltip + '<br />' + status;

            return tooltip;

        });

        self.updateUser = function( source, userInfo )
        {
            var isSelf = self.isSelf;

            var resourcesMap = self.resourcesMap();
            var clientsMap = self.clientsMap();

            var type = userInfo.type || 'available';
            var status = userInfo.status || '';

console.log('updateUser ' + self.displayName() + ' ' + type + ' from ' + source );

// check for jabber offline

            if ( type == 'unavailable' || type == 'unsubscribe' )
            {
                if ( resourcesMap[ source ] )
                {
                    delete resourcesMap[ source ];
                    self.resourcesMap.valueHasMutated();
                }

// another login has gone offline

                if ( ! isSelf )
                    return;

// if no resources remaining and not logged in via another resource then set unavailable

                if ( _.size( resourcesMap ) == 0 )
                {
                    model.idToJabberPresenceTypeMap()[ uberId ] = 'unavailable';
                    model.idToJabberPresenceTypeMap/valueHasMutated();

                    model.idToJabberPresenceStatusMap()[ uberId ] = '';
                    model.idToJabberPresenceStatusMap.valueHasMutated();
                }

// ignore other updates if going offline

                return;
            }

            if ( _.has(userInfo, 'league') )
                self.league( userInfo.league );

            if ( _.has(userInfo, 'leaguePosition' ))
                self.leaguePosition( userInfo.leaguePosition );

            var lastMatchAt = userInfo.lastMatchAt;

            if ( lastMatchAt )
                self.lastMatchAt( lastMatchAt );

            var lastRankChange = userInfo.lastRankChange;

            if ( lastRankChange )
                self.lastRankChange( lastRankChange );

            var resource = resourcesMap[ source ];

            var resourceChanged = false;

            if ( resource )
                resourceChanged = resource.type != type || resource.status != status;
            else
            {
                resource = resourcesMap[ source ] =
                {
                    timestamp: Date.now(),
                };
                resourceChanged = true;
            }

            resource.type = type;
            resource.status = status;

            if ( resourceChanged )
                self.resourcesMap.valueHasMutated();
        }

        self.pendingChat = ko.observable( false );

        self.tags = ko.computed( function()
        {
            var map = model.userTagMap()[ self.uberId() ];
            return map ? map : {};
        });

        self.tagList = ko.computed( function()
        {
            var result = [];

            _.forEach( self.tags(), function( element, key )
            {
                if ( element )
                {
                    result.push( key );
                }
            });

            return result;
        } );

        /*
                function updateTags()
                {
                    var result = model.userTagMap()[ id ];
                    self.tags( result ? result :
                    {} );
                }
                updateTags();
        */

        self.friend = ko.computed( function()
        {
            return self.tags()[ 'FRIEND' ];
        });

        self.pendingFriend = ko.computed( function()
        {
            return self.tags()[ 'PENDING_FRIEND' ];
        });

        self.canUnfriend = ko.computed( function()
        {
            return ! self.isSelf && self.friend();
        });

        self.allowChat = ko.computed( function()
        {
            return self.friend() || self.tags()[ 'ALLOW_CHAT' ]
        });

        self.ignored = ko.computed( function()
        {
            return self.tags()[ 'IGNORED' ];
        });

        self.blocked = ko.computed( function()
        {
            return self.tags()[ 'BLOCKED' ];
        });

        self.canBlock = ko.computed( function()
        {
            return ! self.isSelf && ! self.blocked();
        });

        self.canUnblock = ko.computed( function()
        {
            return ! self.isSelf && self.blocked();
        });

        self.search = ko.computed( function()
        {
            return self.tags()[ 'SEARCH' ];
        });

        self.lastInteractionTime = ko.computed( function()
        {
            return model.idToInteractionTimeMap()[ self.uberId() ]
        });

        self.hasName = ko.computed( function()
        {
            return !!self.displayName();
        });

        self.available = ko.computed( function()
        {
            return self.presenceType() === 'available'
        });

        self.away = ko.computed( function()
        {
            return self.presenceType() === 'away'
        });

        self.dnd = ko.computed( function()
        {
            return self.presenceType() === 'dnd'
        });

        self.offline = ko.computed( function()
        {
            var presenceType = self.presenceType();

            return ! presenceType || presenceType === 'unavailable'
        });

        self.online = ko.computed( function()
        {
            return ! self.offline()
        });

        self.canStartChat = ko.computed( function()
        {
            return ! self.isSelf && self.friend() && self.online();
        });

        self.canSendFriendRequest = ko.computed( function()
        {
            return ! self.isSelf && ! self.friend() && ! self.blocked();
        });

        self.canInviteToChat = ko.computed( function()
        {
            return ! self.isSelf && ! self.friend() && ! self.blocked();
        });

        self.hasPendingInvite = ko.computed( function()
        {
            return model.hasSentInviteTo(self.uberId());
        });

        self.isLobbyContact = ko.computed( function()
        {
            return ! self.isSelf && model.isLobbyContact( self.uberId() );
        });

        self.canInviteToGame = ko.computed( function()
        {
            return ! self.isSelf && model.hasLobbyInfo() && ! self.hasPendingInvite() && ! self.isLobbyContact();
        });

        self.startChat = function()
        {
            model.startConversationsWith( self.uberId() );
        };

        self.startChatIfOnline = function()
        {
            if ( self.offline() )
                return;

            self.startChat()
        }

        self.sendChatInvite = function()
        {
            self.pendingChat( true );
            self.startChat();

            jabber.sendCommand( self.uberId(), 'chat_invite' );
        }

// clicked accept on notification
        self.acceptChatInvite = function()
        {
            jabber.sendCommand( self.uberId(), 'accept_chat_invite' );

            self.addTag( 'ALLOW_CHAT', function()
            {
                self.pendingChat( false )
            });

            self.startChat();
        }

// received jabber accept_chat_invite command
        self.acceptChatInviteReceived = function()
        {
            self.addTag( 'ALLOW_CHAT', function()
            {
                self.pendingChat( false )
            });

            self.startChat();
        }

// clicked decline on notification
        self.declineChatInvite = function()
        {
            if ( ! self.pendingChat() )
                jabber.sendCommand( self.uberId(), 'decline_chat_invite' );
        }

// received jabber decline_chat_invite command
        self.declineChatInviteReceived = function()
        {
        }

        self.sendFriendRequest = function()
        {
            if ( self.friend() )
                return;

            self.addTag( 'PENDING_FRIEND' );

            jabber.sendCommand( self.uberId(), 'friend_request' );
        }

// clicked accept on notification
        self.acceptFriendRequest = function()
        {
            jabber.sendCommand( self.uberId(), 'accept_friend_request' );

            self.addTag( 'FRIEND', function()
            {
                self.removeTag( 'PENDING_FRIEND' )
            });

            jabber.addContact( self.uberId() );
        }

// received accept_friend_request jabber command
        self.acceptFriendRequestReceived = function()
        {
            self.addTag( 'FRIEND', function()
            {
                self.removeTag( 'PENDING_FRIEND' )
            });

            jabber.addContact( self.uberId() );
        }

// clicked decline on notification
        self.declineFriendRequest = function()
        {
            if ( !self.pendingFriend() )
                jabber.sendCommand( self.uberId(), 'decline_friend_request' );

            self.removeTag( 'PENDING_FRIEND' );
        }

// received decline_friend_request jabber command
        self.declineFriendRequestReceived = function()
        {
            self.removeTag( 'PENDING_FRIEND' );
        }

        self.unfriend = function()
        {
            self.removeTag( 'FRIEND' );
            self.removeTag( 'ALLOW_CHAT' );
            jabber.removeContact( self.uberId() );
        }

        self.sendUnfriend = function()
        {
            if ( ! self.friend() )
                return;

            self.unfriend();
            jabber.sendCommand( self.uberId(), 'unfriend' );
        }

        self.sendInviteToGame = function()
        {
            model.sendInviteToGame(self.uberId());
        }

// clicked accept on join game notification
        self.acceptInviteToGame = function()
        {
            model.acceptInviteToGame(self.uberId());
        }

// clicked decline on join game notification
        self.declineInviteToGame = function()
        {
            model.declineInviteToGame(self.uberId());
        }

        self.viewProfile = function()
        {

        }

        self.report = function()
        {
            self.block();
        }

        self.remove = function()
        {
            self.sendUnfriend();
            model.removeAllUserTagsFor( self.uberId() );
//  updateTags();
            _.defer( model.requestUbernetUsers );
        }

        self.addTag = function( tag, callback )
        {
            model.addUserTags( self.uberId(), [ tag ] );
//  updateTags();
            if ( callback )
                callback();
        }

        self.removeTag = function( tag, callback )
        {
            model.removeUserTags( self.uberId(), [ tag ] );
//  updateTags();
            if ( callback )
                callback();
        }

        self.block = function()
        {
            self.addTag( 'BLOCKED', self.sendUnfriend );
            jabber.removeContact( self.uberId() );
        }

        self.unblock = function()
        {
            self.removeTag( 'BLOCKED' );
        }

        self.viewReplays = function()
        {
            model.viewReplays( self.uberId(), self.displayName() );
        }
    };

// end of ExtendedUserViewModel

// ChatRoomModel

    model.ChatRoomModel = function( roomKey, roomName )
    {

        var self = this;

        self.roomKey = roomKey;

        self.roomName = ko.observable( roomName );

        self.showNotifications = ko.observable( true ).extend(
        {
            'local': model.uberId() + '_' + self.roomKey + '_showNotifications'
        } );

        self.toggleNotifications = function()
        {
            self.showNotifications( !self.showNotifications() );
        };

        self.notify = function( message )
        {
            if ( message.me )
                return;

            var mentionsMe = message.mentionsMe;

            var showNotifications = mentionsMe || self.showNotifications();

            var notifyTitle = message.displayName + ' in ' + self.roomName();;
            var notifyMessage = message.message;
            var notifyText = notifyTitle + ': ' + notifyMessage;

            var ageInSeconds = ( Date.now() - message.timestamp ) / 1000;

            var recentMention = mentionsMe && ageInSeconds < 60 * 60;

            if ( ! model.PA && showNotifications )
            {
                var timeout = recentMention ? false : chatDefaultDesktopNotificationTimeout;

                paLobby.showNotification( notifyTitle, notifyMessage, timeout );
            }

            if ( self.minimised() )
            {
                var dirty = self.dirty();

                if ( mentionsMe )
                {
                    if ( model.PA )
                        model.notifyPlayer( notifyText );

// if already dirty then clear so it flashes again on deferred dirty

                    if ( dirty )
                    {
                        self.dirty( false );
                        _.defer( function()
                        {
                            self.dirty( true );
                        });
                    }

                    self.dirtyMention( true );
                }

                if ( ! dirty )
                    self.dirty( true );
            }
            else if ( ! model.showUberBar() && mentionsMe && model.PA )
                model.notifyPlayer( notifyText );
        }

// ! users

        self.moderator = ko.observable( [ '15902732904735349906', '10952182184354445147' ].indexOf( model.uberId() ) != -1 );
        self.muted = ko.observable(false);

        self.usersMap = {};
        self.sortedUsers = ko.observableArray([]).extend( { rateLimit: 200 } );

        self.mutedUsersMap = {};

        self.offlineMutedUsersMap = {};

        self.userMessagesMap = {};

        self.updateRoomUserClientsStatus = function( roomUser )
        {
             var clients = roomUser.clients;
             var loginCount = roomUser.loginCount;

            roomUser.noPA = ! clients.PA && loginCount > 0;
            roomUser.hasWeb = clients.WEB;
            roomUser.isWeb = clients.WEB && loginCount == 1;

            return roomUser;
        }

        self.updateRoomUserTooltip = function( roomUser )
        {
            var clients = roomUser.clients;
            var loginCount = roomUser.loginCount;

            var ladderText = roomUser.ladderText;

            var muted = roomUser.muted;

            var tooltip = roomUser.displayName;

            if ( loginCount > 0 )
            {
                tooltip = tooltip + ' ' + ladderText + ' (' + _.keys( clients ).join( ' / ' ) + ')';

                var muteExpiryText = model.muteExpiryText( muted );

                if ( muteExpiryText )
                    tooltip = tooltip + ' ' + muteExpiryText;
            }

            roomUser.tooltip = tooltip;

            return roomUser;
        }

        self.processJoin = function ( data )
        {
            if ( ! data || typeof data !== 'object' )
                return;

            self.resetRoom();

            var mutedUsers = data.muted;
            var peakUsers = data.peakUsers;
            var cleared = data.cleared;

            self.peakUsers( peakUsers );

            if ( ! self.cleared )
                self.cleared = cleared;

            var mutedUsersToAdd = _.clone( mutedUsers );

            _.forEach( data.users, function( roomUserInfo, uberId )
            {
                self.processRoomUser( roomUserInfo );

                delete mutedUsersToAdd[ uberId ];
            })

// self.usersCount( _.size( data.users ) );

            self.mutedUsersMap = mutedUsers;

// moderator is set while processing room users

            if ( self.moderator() )
            {
                _.forEach( mutedUsersToAdd, function( mutedUser, uberId )
                {
                    self.addMutedUser( uberId, mutedUser.displayName, mutedUser.muted );
                });
            }

            self.sortUsersNeeded( Date.now() );

            self.scrollDown();

            var messages = data.messages;

            if ( messages.length > 0 )
                self.processMessages( messages );
        }

        self.processMessages = function( messages )
        {
            var remaining = messages.length;

            var message;
            var processedMessage;

            var max = Math.min( 100, remaining );

            for (var i = 0; i < max; i++ )
            {
                message = messages[ i ];

                processedMessage = self.processMessage( message, true );

                var ageInSeconds = ( Date.now() - processedMessage.timestamp ) / 1000;

                var recentMention = processedMessage.mentionsMe && ageInSeconds < ( 24 * 60 * 60 );

                if ( recentMention && ! processedMessage.muted && ! processedMessage.deleted && ! processedMessage.blocked )
                    self.notify( processedMessage );
            }

            messages = messages.splice( max );

            if ( messages.length > 0 )
            {
                _.defer( function()
                {
                    self.processMessages( messages )
                })
            }
        }

        self.addMutedUser = function( uberId, displayName, muted )
        {
            var status = 'offline ' + model.muteExpiryText( muted );

            var roomUserInfo =
            {
                user:
                {
                    uberId: uberId,
                    displayName: displayName,
                    client: '',
                    clients: {},
                    resources: {},
                    role: 'muted',
                    roleSortPrefix: 9,
                    status: status,
                    tooltip: status,
                    timestamp: Date.now(),
                    client: undefined,
                    type: undefined,
                    status: status
                },
                clients: {},
                messages: {},
                role: 'muted',
                roleSortPrefix: 9,
                moderator: false,
                offlineMutedUser: true
            }

            self.offlineMutedUsersMap[ uberId ] =
            {
                displayName: displayName,
                muted: muted
            };

            self.processRoomUser( roomUserInfo );
        }

        self.processMute = function( data, muted )
        {
            if ( ! data || typeof data !== 'object' )
                return;

            var uberId = data.uberId;
            var displayName = data.displayName;

            if ( ! uberId )
                return;

            var roomUserWrapper = self.usersMap[ uberId ];
            var roomUserObservable = roomUserWrapper && roomUserWrapper.observable;
            var roomUser = roomUserObservable && roomUserObservable();

            var active = roomUser && roomUser.active;

            var role = muted ? 'muted' : 'user';
            var roleSortPrefix = muted ? 9 : 5;

            var moderator = self.moderator();

            if ( muted )
            {
                self.mutedUsersMap[ uberId ] =
                {
                    displayName: displayName,
                    muted: muted
                };

// inactive muted users not in room are shown for moderators

                if ( moderator && ! roomUser )
                    self.addMutedUser( uberId, displayName, muted );
            }
            else
            {
                delete self.mutedUsersMap[ uberId ];
                delete self.offlineMutedUsersMap[ uberId ];

// inactive unmuted users added for moderators need to be removed

                if ( moderator && roomUser && roomUser.active == false )
                {
// true = remove with no update to messages as we do that below
                    self.removeUser( uberId, true );
                }
            }

            if ( roomUser )
            {
                var roomUserObservable = roomUserWrapper.observable;

                var roomUser = roomUserObservable();

                roomUser.role = role;
                roomUser.roleSortPrefix = roleSortPrefix;
                roomUser.muted = muted;

                roomUser.nameColour = model.nameColour( false, role, roomUser.blocked, muted, roomUserWrapper.displayName );

                self.updateRoomUserTooltip( roomUser );

                roomUserWrapper.sort = roleSortPrefix + roomUserWrapper.displayName;

                roomUserObservable.valueHasMutated();

                self.sortUsersNeeded( true );

// only update if there are message for user

                self.queueUpdateUserMessages( uberId, roomUser );
            }
            else
            {
                var user = model.idToContactMap()[ uberId ];

                var blocked = user && user.blocked();

                var info =
                {
                    active: false,
                    role: role,
                    muted: muted,
                    blocked: blocked
                }

// if no room user we always process all messages (should not happen often)

                self.queueUpdateUserMessages( uberId, info );
            }

            var message = muted ? 'muted' : 'unmuted';

            self.writeStatusMessage( displayName + ' ' + message );

            if ( uberId == model.uberId() )
                self.muted( muted );
        }

        self.tooltip = function( displayName, muted, roomUserInfo )
        {

        }

        self.processRoomUser = function( roomUserInfo )
        {
            var userInfo = roomUserInfo.user;

            var uberId = userInfo.uberId;
            var displayName = userInfo.displayName;

            var role = roomUserInfo.role || 'user';
            var roleSortPrefix = roomUserInfo.roleSortPrefix || 5;

            var lastMessageTimestamp = roomUserInfo.lastMessageTimestamp;
            var clients = roomUserInfo.clients;
            var loginCount = _.size( clients ) || 0;

            var offlineMutedUser = roomUserInfo.offlineMutedUser;

            var roomUserWrapper = self.usersMap[ uberId ];

            var roomUser;

            if ( roomUserWrapper )
            {
                roomUser = roomUserWrapper.observable();

                if ( roomUser.lastMessageTimestamp > lastMessageTimestamp )
                    roomUser.lastMessageTimestamp = lastMessageTimestamp;
            }
            else
            {
                roomUser =
                {
// static
                    uberId: uberId,
                    me: uberId == model.uberId(),
//
                    lastMessageTimestamp: lastMessageTimestamp
                }
            }

// dynamic

// check blocked status

            var user = model.idToContactMap[ uberId ];
            var blocked = user && user.blocked();

            roomUser.displayName = displayName;

            roomUser.role = role;
            roomUser.roleSortPrefix = roleSortPrefix;

            roomUser.loginCount = loginCount;

            var sort = roleSortPrefix + displayName;

            var isAdmin = role == 'admin';
            var isUber = role == 'uber';
            var isSpecial = isAdmin || isUber;

            var moderator = roomUser.moderator = isAdmin || role == 'owner' || role == 'moderator';
            var muted = role == 'muted';

            if ( muted )
            {
                if ( roomUser.muted )
                    muted = roomUser.muted;

                self.mutedUsersMap[ uberId ] =
                {
                    displayName: displayName,
                    muted: muted
                }

                if ( roomUserInfo.muted )
                    muted = roomUserInfo.muted;
            }
            else
                delete self.mutedUsersMap[ uberId ];

            var type = userInfo.type;

            roomUser.active = !! type;
            roomUser.muted = muted;

            roomUser.clients = clients;

            roomUser.type = type;
            roomUser.status = userInfo.status;

            var league = roomUser.league = userInfo.league;
            var leaguePosition = roomUser.leaguePosition = userInfo.leaguePosition;
            var lastMatchAt = roomUser.lastMatchAt = userInfo.lastMatchAt;

            var inactiveDays = roomUser.inactiveDays = model.leagueInactiveDays( lastMatchAt );

            var classic = roomUser.classic = ! roomUser.noPA && _.has( userInfo, 'titans' ) && ! userInfo.titans;

            roomUser.ladderText = isSpecial ? '' : ( classic ? "Classic" : model.ladderText( league, leaguePosition, inactiveDays ) );

            roomUser.leagueImage = model.leagueImage( isAdmin, isUber, league );
            roomUser.leagueImageOpacity = isSpecial ? 1.0 : model.leagueImageOpacity( inactiveDays )

            self.updateRoomUserClientsStatus( roomUser );

            self.updateRoomUserTooltip( roomUser );

            roomUser.offline = ! type || type == 'unavailable';
            roomUser.available = ! roomUser.offline;
            roomUser.away = type == 'away';
            roomUser.dnd = type == 'dnd';

            roomUser.blocked = blocked;

            roomUser.nameColour = model.nameColour( false, role, blocked, muted, displayName );

            if ( roomUserWrapper )
            {
                roomUserWrapper.sort = sort;
                roomUserWrapper.displayName = displayName;
                roomUserWrapper.observable( roomUser );

                if ( ! offlineMutedUser && roomUserWrapper.offlineMutedUser )
                {
                    roomUserWrapper.offlineMutedUser = false;
                    self.usersCount( self.usersCount() + 1 );
                }
            }
            else
            {
                roomUserObservable = ko.observable( roomUser );

                roomUserWrapper =
                {
                    uberId: uberId,
                    sort: sort,
                    displayName: displayName,
                    observable: roomUserObservable,
                    offlineMutedUser: offlineMutedUser
                }

                self.usersMap[ uberId ] = roomUserWrapper;

// push on to end for now for sorting later

                self.sortedUsers.push( roomUserWrapper );

                if ( ! offlineMutedUser )
                    self.usersCount( self.usersCount() + 1 );
            }

            if ( roomUser.me )
            {
                self.moderator( moderator );
                self.muted( muted );
            }

            return roomUser;
        }

        self.resetRoom = function()
        {
            self.usersMap = {};
            self.sortedUsers([]);
            self.mutedUsersMap = {};
            self.offlineMutedUsersMap = {};

            self.usersCount( 0 );

            _.forEach( self.sortedMessages(), function( messageObservable )
            {
                messageObservable().active = false;
                messageObservable.valueHasMutated();
            });

            self.sortedMessages.valueHasMutated();
        }

        self.removeUser = function( uberId, fromMute )
        {
            var mutedUser = self.mutedUsersMap[ uberId ];

            var mutedUserDisplayName = mutedUser && mutedUser.displayName;

            var muted = mutedUser && mutedUser.muted;

            var roomUserWrapper = self.usersMap[ uberId ];

            delete self.usersMap[ uberId ];

            if ( roomUserWrapper )
            {
                if ( ! roomUserWrapper.offlineMutedUser )
                    self.usersCount( self.usersCount() - 1 );

// users are initially added to end so findLastIndex is usually better for quick join / leave

                var index = _.findLastIndex( self.sortedUsers(), { uberId: uberId } );

                if (index != -1 )
                    self.sortedUsers.splice( index, 1 );
            }

// only update messages if not muting

            if ( ! fromMute )
                self.queueUpdateUserMessages( uberId, { active: false, muted: muted } );

            if ( uberId == model.uberId() )
                self.muted( true );

// now check if we need to add back an offline muted user for moderators

            if ( fromMute || ! self.moderator() || ! mutedUserDisplayName )
                return;

            self.addMutedUser( uberId, mutedUserDisplayName, muted );
        }

        self.userMessagesToUpdateMap = ko.observable( {} ).extend( { rateLimit: 1000 } );

        self.userMessagesToUpdateMap.subscribe( function( userMessagesToUpdateMap )
        {
            if ( userMessagesToUpdateMap == {} )
                return;

            self.updateQueuedUserMessages();
        });

        self.queueUpdateUserMessages = function( uberId, update )
        {
             self.userMessagesToUpdateMap() [ uberId ] = update;
             self.userMessagesToUpdateMap.valueHasMutated();
        }

        self.updateQueuedUserMessages = function()
        {
            var lastRealMessage = self.lastRealMessage();

            var lastRealMessageId = lastRealMessage && lastRealMessage._id;
            var lastRealMessageTimestamp = lastRealMessage && lastRealMessage.timestamp;

            var lastRealMessageChanged = false;

            var messagesMap = self.messagesMap;

            var userMessagesMap = self.userMessagesMap;

            var userMessagesToUpdateMap = self.userMessagesToUpdateMap();

            for( uberId in userMessagesToUpdateMap )
            {
                var update = userMessagesToUpdateMap[ uberId ];

                var userMessages = userMessagesMap[ uberId ];

                if ( ! userMessages || _.size( userMessages ) == 0 )
                    continue;

                for ( messageId in userMessages )
                {
                    var messageObservable = messagesMap[ messageId ];

                    var message = messageObservable();

                    var update = userMessagesToUpdateMap[ message.uberId ];

                    if ( ! update )
                        continue;

                    var role = update.role;
                    var active = update.active;
                    var muted = role == 'muted' || update.muted;
                    var blocked = update.blocked;
                    var displayName = update.displayName;

                    var realChange = false;

    // real changes are mutes or blocks

                    message.active = active;

                    var newMuted = message.status == 'muted' || muted;

                    if ( message.muted != newMuted )
                    {
                        message.muted = newMuted;
                        realChange = true;
                    }

                    if ( blocked != undefined )
                    {
                        if ( blocked != message.blocked )
                            realChange = true;

                        message.blocked = blocked;
                    }

                    if ( displayName != undefined )
                        message.displayName = displayName;

                    var userRole = message.role;

                    if ( role != undefined )
                        message.role = role;

                    message.nameColour = model.nameColour( message.me, message.role, message.blocked, muted, message.displayName );

                    messageObservable(message);

    // last real message is changed if there is a real change to last message or more recent

                    if ( realChange && ( lastRealMessageId == message._id || lastRealMessageTimestamp < message.timestamp ) )
                        lastRealMessageChanged = true;
                }
            };

            if ( lastRealMessageChanged )
                self.updateLastMessage();

            self.userMessagesToUpdateMap( {} );
        }

        self.sortUsersNeeded = ko.observable( false ).extend( { rateLimit: 500 } );

        self.sortUsersNeeded.subscribe(function(sortUsersNeeded)
        {
            if (sortUsersNeeded)
                _.defer( function() { self.sortUsers() } );
        });

        self.sortUsers = function()
        {
            var sorted = self.sortedUsers.sort( function( wrapperA, wrapperB )
            {
                return wrapperA.sort.localeCompare( wrapperB.sort );
            });

            self.sortUsersNeeded(false);
        };

        self.peakUsers = ko.observable( 0 );
        self.usersCount = ko.observable( 0 ).extend( { rateLimit: 1000 } );
        self.titansCount = ko.observable( 0 ).extend( { rateLimit: 1000 } );
        self.classicCount = ko.observable( 0 ).extend( { rateLimit: 1000 } );

        self.roomTitle = ko.computed( function()
        {
            var suffix = ' (' + self.usersCount() + ')';

            return self.roomName() + suffix;
        } );

// ! messages

        self.sortedMessages = ko.observableArray( [] );

        self.messagesMap = {};

        self.resetLastRealMessage = function()
        {
            var lastRealMessage = self.lastRealMessage();

            if (lastRealMessage)
            {
                messageId = lastRealMessage._id;

                var message = self.messagesMap[ messageId ];

                if ( message )
                {
                    var m = message();

                    m.highlightTime = false;
                    message.valueHasMutated();
                }
            }
        }

        self.updateLastMessage = function()
        {
            var lastMessageObservable = _.last( self.sortedMessages() );

            var lastMessage = lastMessageObservable && lastMessageObservable();

            self.resetLastRealMessage();

            self.lastMessage( lastMessage );

            var lastRealMessageObservable = lastMessageObservable;
            var lastRealMessage = lastMessage;

            if ( lastRealMessage.system || lastRealMessage.deleted || lastRealMessage.muted || lastRealMessage.blocked )
            {
                lastRealMessageObservable = _.findLast(self.sortedMessages(), function( messageObservable )
                {
                    var message = messageObservable();
                    return ! message.system && ! message.deleted && ! message.muted && ! message.blocked;
                });

                if (lastRealMessageObservable)
                    lastRealMessage = lastRealMessageObservable();
                else
                    lastRealMessage = false;
            }

            if ( lastRealMessage && lastRealMessage.highlightTime == false )
            {
                lastRealMessage.highlightTime = true;
                lastRealMessageObservable.valueHasMutated();
            }

            self.lastRealMessage(lastRealMessage);
        }

        self.sortMessages = function()
        {
            var messages = _.sortBy( self.messagesMap, function( messageObservable, messageId )
            {
                return messageObservable().timestamp;
            } );

            self.sortedMessages(messages);

            self.updateLastMessage();
        }

        self.lastMessage = ko.observable( undefined );

        self.lastRealMessage = ko.observable( undefined );

        self.cleared = 0;

        self.clearHistory = function( timestamp, displayName )
        {
            var message = 'History cleared';

            if ( timestamp )
            {

// might be better to walk sorted messages here

                var messagesMap = self.messagesMap;

                _.forEach( self.sortedMessages(), function( messageObservable )
                {
                    var message = messageObservable();

                    if ( message.timestamp < timestamp )
                    {
                        delete messagesMap[ message._id ];

                        var uberId = message.uberId;

                        var userMessages = self.userMessagesMap[ uberId ];

                        if ( userMessages )
                            delete userMessages[ messageId ];
                    }
                });

                self.sortMessages();

                message = message + ' before ' + model.formatTime( timestamp, true, true );
            }
            else
            {
                self.sortedMessages([]);
                self.messagesMap = {};
                self.userMessagesMap = [];
                self.lastRealMessage(undefined);
                self.lastMessage(undefined);
            }

            if ( displayName )
                message = message + ' by ' + displayName;

            self.writeSystemMessage( message );

// reset last message time for every user

            _.forEach( self.usersMap, function( roomUserWrapper )
            {
                var roomUser = roomUserWrapper.observable();

                if ( ! timestamp || timestamp > roomUser.lastMessageTimestamp )
                    roomUser.lastMessageTimestamp = 0;
            })
        }

        self.processMessage = function( message, historical )
        {

            var uberId = message.uberId;

            var userMessages = self.userMessagesMap[ uberId ];

            if ( ! userMessages )
                userMessages = self.userMessagesMap[ uberId ] = {};

            var messageId = message._id;

            var deleted = message.status == 'deleted';

// deleted are removed for non admins

            if ( deleted && ! self.moderator() )
            {
                delete self.messagesMap[ messageId ];

                if ( userMessages )
                    delete userMessages[ messageId ];

// deletes should not happen often

                var index = _.findIndex( self.sortedMessages(), function( messageObservable )
                {
                    return messageObservable()._id == messageId;
                });

                if (index != -1 )
                {
                    self.sortedMessages.splice( index, 1 );
                    self.updateLastMessage();
                }
                return false;
            }

            var timestamp = message.timestamp;

            userMessages[ messageId ] = timestamp;

            if ( ! timestamp )
                timestamp = message.timestamp = Date.now();

            if ( ! message.system )
                message.system = false;

            if ( ! message.displayName )
                message.displayName = '';

            var language = message.language && CommunityChat.languages[ message.language ];

            if ( message.translated )
                message.tooltip = message.translated + ( language ? ' in ' + language : '' );
            else
                message.tooltip = '';

// roomUser and user may not exist for historical or system messages

            var role = message.role;
            var moderator = message.moderator;

            if (moderator == undefined)
                moderator = false;

            var roomUserWrapper = uberId && self.usersMap[ uberId ];

            if ( roomUserWrapper )
            {
                var roomUser = roomUserWrapper.observable();

                var lastMessageTimestamp = roomUser.lastMessageTimestamp || 0;

                if ( timestamp > lastMessageTimestamp )
                    roomUser.lastMessageTimestamp = timestamp;
            }

            var user = model.idToContactMap()[ uberId ];

            var userBlocked = user && user.blocked() || false;

            var userMuted = !! self.mutedUsersMap[ uberId ];

// static
            message.moderator = moderator;

            message.me = message.uberId == model.uberId();
            message.mentionsMe = ! message.isMe && ! message.system && message.message.toLowerCase().indexOf( model.displayName().toLowerCase() ) !== -1;

            message.parts = model.splitURLs( message.message );

            message.formattedTime = model.formatTime( message.timestamp, true );

            message.nameColour = model.nameColour( message.me, role, userBlocked, userMuted, message.displayName );

// for performance changes to roomUser mute and user block status are applied manually

            message.muted = message.status == 'muted' || userMuted;
            message.deleted = deleted;

            message.blocked = userBlocked;

            message.active = !!roomUserWrapper;

            if (!message.highlightTime)
                message.highlightTime = false;

            message.delta = 0;
            message.deltaPixels = 0;
            message.separator = false;

            var existing = self.messagesMap[ messageId ];

// hopefully messages arrive in order and timestamps are not changed when updating otherwise we have to resort

            var sortRequried = false;

            var realMessage = ! message.system && ! message.deleted && ! message.muted && ! message.blocked;

            var lastMessage = self.lastMessage();
            var lastMessageTimestamp = lastMessage ? lastMessage.timestamp : 0;
            var lastMessageId = lastMessage ? lastMessage.timestamp : 0;

            if ( existing )
            {
                var undeleted = existing.deleted && ! message.deleted && ! self.moderator();

                sortRequired = existing.timestamp != message.timestamp || undeleted;

                existing(message);

                if ( sortRequired )
                    self.sortMessages();
                else
                    self.updateLastMessage();
            }
            else
            {
                var lastMessage = self.lastMessage();
                var lastMessageTimestamp = lastMessage ? lastMessage.timestamp : 0;

                sortRequired = message.timestamp < lastMessageTimestamp;

                if ( ! sortRequired && realMessage )
                    message.highlightTime = true;

                var observableMessage = ko.observable(message);

                self.messagesMap[ messageId ] = observableMessage;

                self.sortedMessages.push( observableMessage );

                if ( sortRequired )
                    self.sortMessages();
                else
                {
// if no sort required then we can just add new messages to end
                    self.lastMessage( message );

                    if ( ! message.system && ! message.muted && ! message.deleted && ! message.blocked )
                    {
                        self.resetLastRealMessage();
                        self.lastRealMessage( message );
                    }
                }
            }

            return message;
        };

        self.canSend = ko.computed( function()
        {
            return model.communityChatReady() && ! self.muted();
        });

        self.chatRoomMessage = ko.observable( '' );

        self.chatRoomMessagePlaceholder = ko.computed( function()
        {
            var placeholder = "play the game, be friendly, don't be a jerk and keep it clean";

            var muted = self.muted();

            if ( muted )
                placeholder = placeholder + ' ( YOU ARE ' + model.muteExpiryText( muted ).toUpperCase() + ' )';

            return placeholder;
        } );

        self.sendChatRoomMessage = function()
        {
            var message = '' + self.chatRoomMessage();

            if ( message.startsWith( '/' ) || message.toLowerCase().trim() == 'help' )
            {
                self.writeSystemMessage( 'Click HELP on top right' );
                self.chatRoomMessage( '' );
                return;
            }

            if ( message.trim() )
                CommunityChat.sendMessage( self.roomKey, message );

            self.chatRoomMessage( '' );
        };

        self.nextSystemMessageId = -1;

        self.writeSystemMessage = function( message, separator )
        {
            var data =
            {
                _id: self.nextSystemMessageId--,
                uberId: undefined,
                displayName: undefined,
                client: undefined,
                parts: model.splitURLs( message ),
                message: message,
                timestamp: Date.now(),
                system: true
            }

            if ( separator )
            {
                data.separator = separator;
            }

            self.processMessage( data );
        };

        self.statusMessages = ko.observableArray([]).extend( { session: 'community_chat_status_messages' } );

        self.writeStatusMessage = function( message )
        {
            var timestamp = Date.now();

            var formattedTime = model.formatTime( timestamp, true );

            var data =
            {
                message: message,
                timestamp: timestamp,
                formattedTime: formattedTime
            }

            self.statusMessages.push( data );
        };

        self.statusMessageCleared = 0;

        self.clearStatusMessages = function()
        {
            var statusMessages = self.statusMessages();

            var statusMessageCleared = self.statusMessageCleared;

            var expiry = Date.now() - chatDefaultStatusMessagesExpiry * 1000;

            var deleted = false;

            for ( var i = statusMessages.length - 1 ; i >= 0; i-- )
            {
                var statusMessage = statusMessages[ i ];

                var timestamp = statusMessage.timestamp;

                if ( timestamp < statusMessageCleared )
                    break;

                if ( timestamp > expiry )
                    continue;

                statusMessages.splice( i, 1 );
                deleted = true;
            }

            if ( deleted )
                self.statusMessages.valueHasMutated();

            self.statusMessageCleared = expiry;
        }

        self.clearStatusMessagesTimer = setInterval( function()
        {
            self.clearStatusMessages();
        }, chatDefaultStatusMessagesTimer * 1000 );

        self.tryFillInTypedName = function()
        {
            var words = self.chatRoomMessage().split( " " );

            if ( words )
            {
                var lastWord = words[ words.length - 1 ];
                var candidates = [];

                if ( lastWord )
                {
                    var uberId = model.uberId();

                    var sortedUsers = self.sortedUsers();

                    for ( var i = 0; i < sortedUsers.length; i++ )
                    {
                        var roomUserWrapper = sortedUsers[ i ];

                        if ( roomUserWrapper.uberId == uberId )
                            continue;

                        var displayName = roomUserWrapper.displayName;

                        if ( displayName.toLowerCase().indexOf( lastWord.toLowerCase() ) !== -1 )
                        {
                            candidates.push( displayName );
                        }
                    }
                }

                candidates = _.uniq( candidates );

                if ( candidates.length === 1 )
                {
                    self.chatRoomMessage( self.chatRoomMessage().slice( 0, self.chatRoomMessage().length - lastWord.length ) + candidates[ 0 ] );
                }
                else if ( candidates.length > 1 )
                {
                    var list = "";
                    for ( var i = 0; i < candidates.length; i++ )
                    {
                        list += candidates[ i ] + " ";
                    }
                    self.writeSystemMessage( list );
                }
            }
        };

        self.systemMessageCleared = 0;

        self.clearSystemMessages = function()
        {
            var sortedMessages = self.sortedMessages();

            var systemMessageCleared = self.systemMessageCleared;

            var expiry = Date.now() - chatDefaultSystemMessagesExpiry * 1000;

            var messagesMap = self.messagesMap;

            var deleted = false;

            for ( var i = sortedMessages.length - 1 ; i >= 0; i-- )
            {
                var messageObservable = sortedMessages[ i ];

                var message = messageObservable();

                var timestamp = message.timestamp;

                if ( timestamp < systemMessageCleared )
                    break;

                if ( timestamp > expiry )
                    continue;

                if ( message.system )
                {
                    sortedMessages.splice( i, 1 );
                    delete messagesMap[ message._id ];
                    deleted = true;
                }
            }

            if ( deleted )
                self.sortedMessages.valueHasMutated();

            self.systemMessageCleared = expiry;
        }

        self.clearSystemMessagesTimer = setInterval( function()
        {
            self.clearSystemMessages();
        }, chatDefaultSystemMessagesTimer * 1000 );

        self.helpMessages = ko.observableArray([]).extend( { session: 'community_chat_help_messages' } );

        self.helpMessageCleared = 0;

        self.clearHelpMessagesTimer = false;

        self.clearHelpMessages = function()
        {
            var helpMessages = self.helpMessages();

            var helpMessageCleared = self.helpMessageCleared;
            var suggestionTimestamps = self.suggestionTimestamps;

            var expiry = Date.now() - chatDefaultHelpMessagesExpiry * 1000;

            var deleted = false;

            for ( var i = helpMessages.length - 1 ; i >= 0; i-- )
            {
                var helpMessage = helpMessages[ i ];

                var key = helpMessage.key;
                var timestamp = helpMessage.timestamp;

                if ( timestamp < helpMessageCleared )
                    break;

                if ( timestamp > expiry )
                    continue;

                helpMessages.splice( i, 1 );
                deleted = true;
            }

            if ( deleted )
                self.helpMessages.valueHasMutated();

            self.helpMessageCleared = expiry;
        }

        self.clearHelpMessagesTimer = setInterval( function()
        {
            self.clearHelpMessages();
        }, chatDefaultHelpMessagesTimer * 1000 );

        self.mentionHelpMessage = function( helpMessage )
        {
            var message = self.chatRoomMessage();

            if ( message && message.substr( -1, 1 ) != ' ' )
                message = message + ' ';

            self.chatRoomMessage( message + helpMessage.text + ': ' + helpMessage.url );

            return false;
        }

        self.showAllHelpMessages = function()
        {
            var suggestionMessages = self.suggestionMessages;

           var helpMessages = [];

            _.forEach( self.suggestionMessages, function( suggestionMessage )
            {
                if (_.isObject(suggestionMessage) && suggestionMessage.url )
                {
                    helpMessages.push(
                    {
                        text: suggestionMessage.text,
                        title: suggestionMessage.title || suggestionMessage.text,
                        url: suggestionMessage.url,
                        timestamp: Date.now()
                    });
                }
            });

            self.helpMessages(helpMessages);
        };

        self.suggestions =
        [
            {
                startsWith: 'sale',
                suggestions: ['upgrade', 'titans', 'timeline']
            },
            {
                word: 'help',
                suggestions: ['learning-to-play', 'guides', 'ui', 'skills', 'vocabulary', 'units', 'queller', 'hotkeys', 'titans', 'timeline', 'mods', 'sim', 'servers', 'reporting-issues']
            },
            {
                startsWith: 'support',
                suggestions: ['learning-to-play', 'guides', 'ui', 'skills', 'vocabulary', 'units', 'queller', 'hotkeys', 'titans', 'timeline', 'mods', 'sim', 'servers', 'reporting-issues', 'support']
            },
            {
                startsWith: 'new',
                suggestions: ['pa-inc', 'learning-to-play', 'guides', 'ui', 'skills', 'units', 'queller', 'hotkeys', 'titans', 'legion', 'mods']
            },
            {
                startsWith: 'learn',
                suggestions: ['learning-to-play', 'guides', 'ui', 'skills', 'units', 'queller', 'hotkeys', 'titans', 'legion', 'mods']
            },
            {
                word: 'panet',
                suggestions: ['panet', 'pte']
            },
            {
                word: 'ubernet',
                suggestions: ['panet', 'pte']
            },
            {
                word: 'pte',
                suggestions: ['panet', 'pte']
            },
            {
                startsWith: 'guide',
                suggestions: ['learning-to-play', 'guides', 'ui', 'skills', 'vocabulary', 'units', "queller", 'hotkeys', 'sim', 'servers']
            },
            {
                word: 'tips',
                suggestions: ['learning-to-play', 'guides', 'ui', 'skills', 'vocabulary', 'units', "queller", 'hotkeys', 'sim', 'servers']
            },
            {
                word: 'interface',
                suggestions: ['learming-to-play', 'ui', 'guides', 'vocabulary']
            },
            {
                startsWith: 'control',
                suggestions: ['learning-to-play', 'ui', 'guides', 'skills', 'vocabulary']
            },
            {
                startsWith: 'eco',
                suggestions: ['learning-to-play', 'vocabulary', 'skills', 'guides' ]
            },
            {
                word: 'macro',
                suggestions: ['learning-to-play', 'vocabulary', 'skills', 'guides' ]
            },
            {
                word: 'micro',
                suggestions: ['learning-to-play', 'vocabulary', 'skills', 'guides' ]
            },

            {
                startsWith: 'hotkey',
                suggestions: ['hotkeys', 'guides']
            },
            {
                word: 'hotbuild',
                suggestions: ['hotkeys', 'guides']
            },
            {
                startsWith: 'fix',
                suggestions: ['panet', 'windows-incompatible-software', 'timeline', 'sim', 'servers', 'reporting-issues', 'support']
            },
            {
                startsWith: 'crash',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues', 'support']
            },
            {
                startsWith: 'issue',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues', 'support']
            },
            {
                startsWith: 'simulation',
                suggestions: ['panet', 'firewall-antivirus', 'reporting-issues']
            },
            {
                startsWith: 'bug',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues', 'support']
            },
            {
                startsWith: 'defect',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues', 'support']
            },
            {
                word: 'broken',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues', 'support']
            },
            {
                startsWith: 'lag',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues']
            },
            {
                startsWith: 'sim',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues']
            },
            {
                word: 'performance',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues']
            },
            {
                startsWith: 'freez',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues']
            },
            {
                word: 'fps',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues']
            },
            {
                startsWith: 'stutter',
                suggestions: ['panet', 'windows-incompatible-software', 'sim', 'servers', 'reporting-issues']
            },
            {
                word: 'windows',
                suggestions: ['windows-incompatible-software', 'sim', 'servers', 'reporting-issues']
            },
            {
                startsWith: 'virus',
                suggestions: ['windows-incompatible-software', 'reporting-issues']
            },
            {
                startsWith: 'malware',
                suggestions: ['windows-incompatible-software', 'reporting-issues']
            },
            {
                startsWith: 'firewall',
                suggestions: ['windows-incompatible-software', 'servers', 'reporting-issues']
            },
            {
                startsWith: 'connect',
                suggestions: ['windows-incompatible-software', 'servers', 'reporting-issues']
            },
            {
                word: 'pamm',
                suggestions: ['pamm']
            },
            {
                system: true,
                startsWith: 'rule',
                suggestions: ['help']
            },
            {
                system: true,
                startsWith: 'jerk',
                suggestions: ['help']
            },
            {
                word: 'titans',
                suggestions: ['titans', 'units', 'legion', 'timeline']
            },
            {
                startsWith: 'update',
                suggestions: ['pa-inc', 'news', 'timeline', 'servers']
            },
            {
                word: 'timeline',
                suggestions: ['pa-inc', 'news', 'timeline']
            },
            {
                word: 'alpha',
                suggestions: ['pa-inc', 'news', 'timeline', 'units']
            },
            {
                word: 'classic',
                suggestions: ['pa-inc', 'news', 'timeline']
            },
            {
                startsWith: 'euro',
                suggestions: ['pa-inc', 'news', 'timeline', 'general' ]
            },
            {
                startsWith: 'dollar',
                suggestions: ['pa-inc', 'news', 'timeline', 'general' ]
            },
            {
                startsWith: '$',
                suggestions: ['pa-inc', 'news', 'timeline', 'general' ]
            },
            {
                startsWith: 'beta',
                suggestions: ['pa-inc', 'news', 'timeline', 'units']
            },
            {
                word: 'release',
                suggestions: ['pa-inc', 'news', 'timeline', 'titans']
            },
            {
                word: 'money',
                suggestions: ['pa-inc', 'news', 'timeline', 'general']
            },
            {
                word: 'finished',
                suggestions: ['pa-inc', 'news', 'timeline', 'general']
            },
            {
                word: 'unfinished',
                suggestions: ['pa-inc', 'news', 'timeline', 'general']
            },
            {
                word: 'incomplete',
                suggestions: ['pa-inc', 'news', 'timeline', 'general']
            },
            {
                startsWith: 'scam',
                suggestions: ['pa-inc', 'news', 'timeline', 'general']
            },
            {
                startsWith: 'scum',
                suggestions: ['pa-inc', 'news', 'timeline', 'general']
            },
            {
                startsWith: 'develop',
                suggestions: ['pa-inc', 'news', 'timeline', 'mods', 'general']
            },
            {
                word: 'devs',
                suggestions: ['pa-inc', 'news', 'timeline', 'mods', 'general']
            },
            {
                startsWith: 'buy',
                suggestions: ['pa-inc', 'news', 'titans', 'timeline', 'legion']
            },
            {
                word: 'paid',
                suggestions: ['pa-inc', 'news', 'titans', 'timeline', 'legion']
            },
            {
                startsWith: 'pay',
                suggestions: ['pa-inc', 'news', 'titans', 'timeline', 'legion']
            },
            {
                startsWith: 'cash',
                suggestions: ['pa-inc', 'news', 'timeline', 'general']
            },
            {
                startsWith: 'faction',
                suggestions: ['legion', 'units']
            },
            {
                word: 'legion',
                suggestions: ['legion', 'units']
            },
            {
                word: 'expansion',
                suggestions: ['pa-inc', 'news', 'titans', 'legion', 'units', 'timeline', 'servers' ]
            },
            {
                word: 'dlc',
                suggestions: ['pa-inc', 'news', 'upgrade', 'titans', 'legion', 'units', 'timeline', 'servers' ]
            },
            {
                startsWith: 'upgrade',
                suggestions: ['panet', 'pa-inc', 'news', 'upgrade', 'titans', 'legion', 'units', 'timeline', 'servers' ]
            },
            {
                startsWith: 'unit',
                suggestions: ['legion','units']
            },
            {
                word: 'mods',
                suggestions: ['mods', 'legion', 'queller', 'pamm', 'servers']
            },
            {
                word: 'modding',
                suggestions: ['mods', 'legion', 'queller', 'pamm', 'servers']
            },
            {
                word: 'ladder',
                suggestions: ['ranked']
            },
            {
                startsWith: 'rank',
                suggestions: ['ranked']
            },
            {
                word: 'matchmaking',
                suggestions: ['ranked']
            },
            {
                word: 'gw',
                suggestions: ['gw']
            },
            {
                word: 'galactic',
                suggestions: ['gw']
            },
            {
                word: 'loadout',
                suggestions: ['gw']
            },
            {
                word: 'local',
                suggestions: ['servers', 'sim', 'windows-incompatible-software', 'reporting-issues'],
            },
            {
                startsWith: 'server',
                suggestions: ['servers', 'sim', 'windows-incompatible-software', 'reporting-issues'],
            },
            {
                startsWith: 'sim',
                suggestions: ['servers', 'sim', 'windows-incompatible-software', 'reporting-issues'],
            },
            {
                word: 'playfab',
                suggestions: ['windows-incompatible-software', 'servers'],
            },
            {
                startsWith: 'host',
                suggestions: ['servers', 'sim' ],
            },
            {
                word: 'discord',
                suggestions: ['discord']
            },
            {
                word: 'voice',
                suggestions: ['discord']
            },
            {
                word: 'ai',
                suggestions: ['queller']
            },
            {
                word: 'skirmish',
                suggestions: ['queller']
            },
            {
                word: 'queller',
                suggestions: ['queller']
            },
            {
                startsWith: 'friend',
                suggestions:[ 'friends' ]
            },
            {
                startsWith: 'name',
                suggestions:[ 'friends' ]
            },
            {
                startsWith: 'nickname',
                suggestions:[ 'friends' ]
            },
            {
                word: 'invite',
                suggestions:[ 'friends' ]
            },
            {
                startsWith: 'link',
                suggestions:[ 'lost-titans-ownership' ]
            },
            {
                word: 'lost',
                suggestions:[ 'lost-titans-ownership' ]
            },
            {
                system: true,
                startsWith: 'hitler',
                suggestions: ['loser2', 'help']
            },
            {
                system: true,
                startsWith: 'nigger',
                suggestions: ['loser2', 'help']
            },
            {
                system: true,
                startsWith: 'nigga',
                suggestions: ['loser2', 'help']
            },
            {
                system: true,
                startsWith: 'fagg',
                suggestions: ['loser2', 'help']
            },
            {
                system: true,
                startsWith: 'jews',
                suggestions: ['loser2', 'help']
            },
            {
                system: true,
                startsWith: 'kys',
                suggestions: ['loser2', 'help']
            },
            {
                system: true,
                word: 'hi',
                suggestions: ['hello']
            },
            {
                system: true,
                word: 'helo',
                suggestions: ['hello']
            },
            {
                system: true,
                word: 'hello',
                suggestions: ['hello']
            },
        ]

        self.suggestionMessages =
        {
            'upgrade': { text: loc('!LOC:Classic PA players upgrade to Titans for US$3.99 (90% off)'), url: 'https://store.steampowered.com/app/386070/Planetary_Annihilation_TITANS/' },
            'ranked': { text: loc('!LOC:TITANS 1v1 ranked'), url: 'https://planetaryannihilation.com/titans-1v1-ranked/' },
            'support': { text: 'Planetary Annihilation Support', url: 'https://support.planetaryannihilation.com/' },
            'discord': { text: loc('!LOC:Official Planetary Annihilation Discord'), url: 'https://discord.gg/pa' },
		    'rules': { text: loc('!LOC:Community Rules and Guidelines'), url: 'https://planetaryannihilation.com/community-rules-and-guidelines/' },
            'guides': { text: loc('!LOC:Player Guides'), url: 'https://planetaryannihilation.com/guides/' },
            'learning-to-play': { text: loc('!LOC:Learning to Play'), url: 'https://planetaryannihilation.com/guides/learning-to-play-planetary-annihilation/'},
            'ui': { text: loc('!LOC:User Interface Controls'), url: 'https://planetaryannihilation.com/guides/controls-and-the-user-interface/' },
            'skills': { text: loc('!LOC:Skills Pyramid'), url: 'https://planetaryannihilation.com/guides/climbing-the-skills-pyramid/' },
            'queller': { text: loc('!LOC:Queller AI mod for Skirmish & Multiplayer'), url: 'https://planetaryannihilation.com/guides/queller-ai-for-multiplayer-and-ai-skirmish/' },
            'gw': { text: loc('!LOC:Galactic War'), url: 'https://planetaryannihilation.com/guides/galactic-war-difficulty-and-adding-more-maps/' },
            'dedicated-servers': { text: loc('!LOC:Dedicated Servers'), url: 'https://planetaryannihilation.com/dedicated-server-rules-and-guidelines/'},
            'servers': { text: loc('!LOC:Custom / Local Servers and LAN / WAN Games'), url: 'https://planetaryannihilation.com/guides/hosting-a-local-server/' },
            'vocabulary': { text: loc('!LOC:Planetary Annihilation Vocabulary'), url: 'https://planetaryannihilation.com/guides/planetary-annihilation-vocabulary/' },
            'ui-is-slow': { text: loc('!LOC:UI is Slow'), url: 'https://support.planetaryannihilation.com/kb/faq.php?id=48' },
            'full-screen': { text: loc('!LOC:Full Screen Desktop Resolution'), url: 'https://support.planetaryannihilation.com/kb/faq.php?id=224' },
            'lost-titans-ownership': { text: loc('!LOC:Lost Titans Ownership When Linking'), url: 'https://support.planetaryannihilation.com/kb/faq.php?id=63' },
            'news': { text: 'Planetary Annihilation News', url: 'https://planetaryannihilation.com/news/' },
            'pa-inc': { text: 'Planetary Annihilation Inc', url: 'https://planetaryannihilation.com/news/planetary-annihilation-inc-the-future-of-pa-and-titans/' },
            'panet': { text: loc('!LOC:PAnet Migration'), url: 'https://planetaryannihilation.com/news/panet-migration/' },
            'pte': { text: loc('!LOC:Public Test Environments (PTE)'), url: 'https://planetaryannihilation.com/guides/planetary-annihilation-public-test-environments-pte/' },
            'hello': loc('!LOC:hello'),
            'help': loc('!LOC:click HELP on top right'),
            'big-game-replays': { text: loc('!LOC:if you have plenty of RAM then you can download and watch big game replays'), title: loc('!LOC:Big Game Replays'), url: 'https://palobby.com/replays/'},
            'units': { text: loc('!LOC:Unit Database'), url: 'https://palobby.com/units/' },
            'mods': { text: loc('!LOC:Community Mods'), url: 'https://palobby.com/community-mods/' },
            'reporting-issues': { text: loc('!LOC:Reporting Issues'), url: 'https://wiki.palobby.com/wiki/Reporting_Issues'},
            'firewall-antivirus': { text: loc('!LOC:Check firewall / antivirus and Incompatible Windows Software (eg disable GameFirst)'), title: loc('!LOC:Firewall / Antivirus / Incompatible Windows Software'), url: 'https://wiki.palobby.com/wiki/Windows_Incompatible_Software' },
            'windows-incompatible-software': { text: loc('!LOC:Check Incompatible Windows Software (eg disable GameFirst)'), title: loc('!LOC:Incompatible Windows Software'), url: 'https://wiki.palobby.com/wiki/Windows_Incompatible_Software' },
            'special-characters': { text: loc('!LOC:Special Characters in Display Name'), url: 'https://wiki.palobby.com/wiki/Special_Characters_in_Display_Name' },
            'titans': { text: loc('!LOC:Titans Overview'), url: 'https://exodusesports.com/article/planetary-annihilation-titans/' },
            'legion': { text: loc('!LOC:Legion Expansion Overview'), url: 'https://exodusesports.com/article/legion-expansion-community-faction-mod/' },
            'timeline': { text: loc('!LOC:Timeline of updates to Titans & Classic PA'), url: 'https://planetaryannihilation.com/timeline/' },
            'hotkeys': { text: loc('!LOC:Hot Keys'), url: 'https://exodusesports.com/guides/planetary-annihilation-hotkeys-super-guide/' },
            'sim': { text: loc('!LOC:Server Sim Performance / Time Dilation / RAM Usage'), url: 'https://planetaryannihilation.com/support/server-performance/' },
            'general': { text: loc('!LOC:General Discussion Forum'), url: 'https://forums.planetaryannihilation.com/forums/pa-titans-general-discussion.96/' },
            'friends': { text: loc('!LOC:PA Friends & Display Names'), url: 'https://wiki.palobby.com/wiki/Planetary_Annihilation_Friends_and_Display_Names' },
            'pamm': { text: loc('!LOC:Old PAMM Mods'), url: 'https://wiki.palobby.com/wiki/Planetary_Annihilations_Titans_%26_Classic_PA_Mod_Manager_PAMM' },
            'loser': loc("!LOC:DON'T BE A JERK"),
            'loser2': loc("!LOC:DON'T BE A LOSER")
        }

        self.suggestionTimestamps = {};

        self.chatRoomMessageDelayed = ko.pureComputed( self.chatRoomMessage ).extend( { rateLimit: {  method: "notifyWhenChangesStop", timeout: 400 } } );

        self.chatRoomMessageDelayed.subscribe( function( chatRoomMessage )
        {
            var lowercaseMessage = chatRoomMessage.toLowerCase().trim();

            var suggestions =  self.suggestions;
            var suggestionTimestamps = self.suggestionTimestamps;
            var suggestionMessages = self.suggestionMessages;

            var systemMessageCleared = self.systemMessageCleared;
            var helpMessageCleared = self.helpMessageCleared;

            for ( var i = 0; i < suggestions.length; i++ )
            {
                var suggestion = suggestions[ i ];

                var word = suggestion.word;

                var startsWith = suggestion.startsWith;

                var words = _.words( lowercaseMessage );

                var found = false;

                for ( var j = 0; j < words.length; j++ )
                {
                    var aWord = words[j];

                    if ( ( word && aWord == word ) || ( startsWith && aWord.startsWith( startsWith ) ) )
                    {
                        found = true;
                        break
                    }
                }

                if ( found )
                {
                    var keys = suggestion.suggestions;

                    for ( var j = 0; j < keys.length; j++ )
                    {
                        var key = keys[ j ];

                        var timestamp = suggestionTimestamps[ key ] || 0;

                        if ( timestamp < systemMessageCleared )
                        {
                            var suggestionMessage = suggestionMessages[ key ];

                            if ( suggestionMessage )
                            {
                                var text;
                                var title;
                                var url = false;

                                if (_.isObject(suggestionMessage))
                                {
                                    url = suggestionMessage.url;
                                    text = suggestionMessage.text;
                                    title = suggestionMessage.title || suggestionMessage.text;
                                }
                                else
                                {
                                    text = suggestionMessage;
                                    title = suggestionMessage;
                                }

                                if ( suggestion.system )
                                    self.writeSystemMessage( text );
                                else
                                    self.helpMessages.push(
                                    {
                                        text: text,
                                        title: title,
                                        url: url,
                                        timestamp: Date.now()
                                    });

                                suggestionTimestamps[ key ] = Date.now();
                            }
                        }
                    }
                }
            }
        });

        self.chatRoomMessageKeyDown = function( s, event )
        {
            if ( event.which === 9 )
            {
                self.tryFillInTypedName();
                return false;
            }

            return true;
        };

        self.mention = function( displayName )
        {
            var message = self.chatRoomMessage();

            if ( message && message.substr( -1, 1 ) != ' ' )
            {
                message = message + ' ';
            }

            self.chatRoomMessage( message + displayName + ' ' );
        }

// ! window

        self.minimised = ko.observable( false );

        self.notMinimised = ko.computed( function()
        {
            return ! self.minimised();
        })

        self.tooltip = ko.computed( function()
        {
            var tooltip = self.minimised() ? loc('!LOC:click to maximise') : loc('!LOC:click title bar to minimise');

            return tooltip;
        });

        self.maxHeight = ko.computed( function()
        {
            return model.maxHeight() * 100 + '%';
        });

        self.heightCss = ko.computed( function()
        {
            return self.minimised() ? '34px' : '100%';
        });

        self.dirty = ko.observable( false );

        self.dirtyMention = ko.observable( false );

        self.clearDirtyMention = function()
        {
            self.dirtyMention( false );
        }

        self.clearTooltips = function()
        {
            $( '#chat-room-' + self.roomKey + ' .div-chat-room-title').tooltip( 'hide' );
            $( '#chat-room-' + self.roomKey + ' .chat-message-text').tooltip( 'hide' );
        };

        self.toggleMinimised = function()
        {
            self.clearTooltips();
            self.minimised( !self.minimised() );
        };

        self.maximize = function()
        {
            self.clearTooltips();
            self.minimised( false );
        };

        self.minimised.subscribe( function( minimised )
        {
            if ( minimised )
                model.releaseScroll();
            else
            {
                self.dirty( false );
                self.dirtyMention( false );
            }

            self.scrollDown();
        } );

        self.scrollDown = function()
        {
            _.defer( function()
            {
                $messages = $( '#chat-room-' + self.roomKey + ' .div-chat-room-messages' );

                if ( $messages.length > 0 )
                {
                    $messages.scrollTop( $messages[ 0 ].scrollHeight );
                }
            } );
        };

        self.close = function()
        {
            self.clearTooltips();
            model.leaveRoom( self.roomKey );
            model.releaseScroll();
        };
    }

// end of ChatRoomModel

// ExtendedNotificationViewModel

    model.ExtendedNotificationViewModel = function(options /* uberId type */)
    {
        var self = this;

        self.lobbyInfo = ko.observable(options.lobbyInfo);
        self.hasLobbyInfo = ko.computed(function()
        {
            var lobbyInfo = self.lobbyInfo();

            return !! lobbyInfo;
        });

        self.lobbyStatus = ko.observable(options.lobbyStatus || '');

        self.isNew = ko.observable(true);

        self.type = ko.observable(options.type);
        self.isFriendRequest = ko.computed(function () { return self.type() === 'friend_request' });
        self.isGameInvite = ko.computed(function () { return self.type() === 'game_invite' });
        self.isChatInvite = ko.computed(function () { return self.type() === 'chat_invite' });

        self.partnerUberId = ko.observable(options.uberId || options.uberid );

        self.partner = ko.computed(function () { return model.idToContactMap()[self.partnerUberId()] });
        self.partnerDisplayName = ko.computed(function () {
            return self.partner() ? self.partner().displayName() : self.partnerUberId();
        });

        self.ignore = function () {
            if (self.partner()) {
                if (self.isFriendRequest())
                    self.partner().declineFriendRequest();
                if (self.isGameInvite())
                    self.partner().declineInviteToGame();
                if (self.isChatInvite())
                    self.partner().declineChatInvite();
            }
            model.clearNotification(self);
        }
        self.ok = function () {
            if (self.partner()) {
                if (self.isFriendRequest())
                    self.partner().acceptFriendRequest();
                if (self.isGameInvite()) {
                    self.partner().acceptInviteToGame();

                    if (self.hasLobbyInfo()) {
                        model.maybeJoinGameLobby(self.lobbyInfo());
                    }
                }
                if (self.isChatInvite())
                    self.partner().acceptChatInvite();
            }
            model.clearNotification(self);
        }
        self.block = function () {
            if (self.partner()) {
                self.partner().declineFriendRequest();
                self.partner().block();
            }
            model.clearNotification(self);
        }
        self.report = function () {
            if (self.partner()) {
                self.partner().declineFriendRequest();
                self.partner().report();
            }
            model.clearNotification(self);
        }
    };

// end of NotificationViewModel

// ExtendedConversationViewModel

    model.ExtendedConversationViewModel = function( uberId )
    {
        var self = this;

		self.scrollDown = function()
		{
			setTimeout(function()
			{
			  $conversation = $( '#conversation-' + self.partnerUberId() );

				if ( $conversation.length > 0)
				{
					$conversation.scrollTop( $conversation[0].scrollHeight );
				}
			}, 0);
		};

		self.showNotifications = ko.observable( true );

		self.toggleNotifications = function()
		{
  		  self.showNotifications( ! self.showNotifications() );
		};

        self.partnerUberId = ko.observable( uberId );

        self.minimised = ko.observable(false);

        self.notMinimised = ko.computed( function()
        {
            return ! self.minimised();
        })

        self.toggleMinimised = function ()
        {
            self.minimised( !self.minimised() );
        };

        self.minimised.subscribe(function ( minimised )
        {
            if ( minimised )
                model.releaseScroll();
            else
                self.dirty(false);
        });

        self.maxHeight = ko.computed( function()
        {
            return model.maxHeight() * 100 + '%';
        });

        self.heightCss = ko.computed( function()
        {
            return self.minimised() ? '34px' : '100%';
        });

        self.dirty = ko.observable(false);

        self.messageLog = ko.observableArray([/* { name message } */]);

        self.addMessage = function ( message )
        {
            message.parts = model.splitURLs( message.message );

            message.timestamp = Date.now();

            message.formattedTime = model.formatTime( message.timestamp, true, false );

            message.me = false;

            self.messageLog.push( message );

            self.dirty( self.minimised() );

            if ( self.showNotifications() )
            {
                var notifyTitle = self.partner().displayName() + ' in private chat';
                var notifyMessage = message.message;
                var notifyText = notifyTitle + ': ' + notifyMessage;

                if ( model.PA )
                    model.notifyPlayer( notifyText );
                else
                    paLobby.showNotification( notifyTitle, notifyMessage, false );
            }
        };

        self.partner = ko.computed( function ()
        {
            return model.idToContactMap()[self.partnerUberId()]
        });

        self.partnerDisplayName = ko.computed(function ()
        {
            return self.partner() ? self.partner().displayName() : self.partnerUberId();
        });

        self.partnerDisplayName.subscribe( function ( partnerDisplayName )
        {
            _.forEach( self.messageLog(), function ( message )
            {
                if ( ! message.self )
                    message.name = partnerDisplayName;
            });
        });

        self.reply = ko.observable();

        self.sendReply = function()
        {
            var msg = self.reply();

            jabber.sendChat( self.partnerUberId(), msg );

            var timestamp = Date.now();
            var formattedTime = model.formatTime( timestamp, false, false );

            var parts = model.splitURLs( msg );

            self.messageLog.push(
            {
                name: model.displayName(),
                message: msg,
                parts: parts,
                timestamp: timestamp,
                formattedTime: formattedTime,
                me: true
            });

            self.reply( '' );
        };

        self.close = function ()
        {
            model.endConversationsWith( self.partnerUberId() );
            model.releaseScroll();
        }
    };

// end of ExtendedConversationViewModel

// the following need to use ExtendedNotificationViewModel

    model.maybeAddFriendRequest = function (uberId, command)
    {
        var contact = model.idToContactMap()[uberId];

        if (contact.blocked() || model.friendRequestMap()[uberId])
            return;

        model.notifications.push(new model.ExtendedNotificationViewModel({ uberId: uberId, type: command.message_type }));
    }

    model.maybeAddGameInvite = function (uberId, command)
    {
        var contact = model.idToContactMap()[uberId];

        if (contact.blocked())
            return;

        var payload = command.payload;
        var info = undefined;
        var status = '';

// new invite format
        if (payload) {
            info = payload.info;
            status = payload.status;
        };

// update or delete any existing invite

        var existing = model.gameInviteMap()[uberId];

        if (existing) {
            existing.lobbyInfo(info);
            existing.lobbyStatus(status);
            return;
        }

        model.notifications.push(new model.ExtendedNotificationViewModel({ uberId: uberId, type: command.message_type, lobbyInfo: info, lobbyStatus: status }));
    }

    model.maybeAddChatInvite = function (uberId, command)
    {
        var contact = model.idToContactMap()[uberId];

        if (contact.blocked() || model.chatInviteMap()[uberId])
            return;

        model.notifications.push(new model.ExtendedNotificationViewModel({ uberId: uberId, type: command.message_type }));
    }

// !

// the following from uber.js need to use our ExtendedUserViewModel

    model.addContact = function( ubername, uberId, tags )
    {

        if ( uberId == model.uberId() )
            return model.user();

        model.addUserTags( uberId, tags );

        var user = new model.ExtendedUserViewModel( uberId );

        model.users.push( user );

        return user;
    }

    model.optimiseMaps = function ()
    {

        var interaction_time_map = model.idToInteractionTimeMap();

        var cutoff = Date.now() - 2 * 24 * 60 * 60 * 1000;

        var optimised = _.transform(model.userTagMap(), function(result, value, key, object) {

            var lastInteraction = interaction_time_map[ key ];

    // keep friends, pending friends, chats and any searches or contacts within last 30 days

            if (value.FRIEND || value.PENDING_FRIEND || value.ALLOW_CHAT || ( lastInteraction && lastInteraction > cutoff ))
                result[ key ] = value;

            return result;
        }, {});

        model.userTagMap( optimised );

        var optimised = _.transform(interaction_time_map, function(result, value, key, value) {

            var lastInteraction = interaction_time_map[ key ];

    // keep friends, pending friends, chats and any searches or contacts within last 30 days

            if (value > cutoff) {
                result[ key ] = value;
            }

            return result;
        }, {});

        model.idToInteractionTimeMap( optimised );

    }

    model.requestUbernetUsers = function()
    {
        model.maybeConvertFriends();

        model.optimiseMaps();

        var contacts = _.reject( _.keys( model.userTagMap() ), function( element )
        {
            return isNaN( element );
        } );
        var results = _.map( contacts, function( uberId )
        {
            return new model.ExtendedUserViewModel( uberId );
        } );

        model.users( results );
    };

    model.maybeCreateNewContactWithId = function( uberId, noInteraction )
    {
        if ( uberId == model.uberId() )
            return model.user();

        var user = model.idToContactMap()[ uberId ];

        if ( ! user )
            user = model.addContact( '', uberId, [ 'CONTACT' ] );

        if ( user )
        {
            if ( !noInteraction )
            {
                model.idToInteractionTimeMap()[ uberId ] = Date.now();
                model.idToInteractionTimeMap.valueHasMutated();
            }
        }

        return user;
    }

// !
// ! MODEL
// !

// improvements and patchs to uberbar.js

    model.isNewDisplayNameInvalid = ko.computed(function ()
    {
        var displayName = model.newDisplayName();

        return !displayName
                || !displayName.length
                || displayName.length < 2
                || displayName.length > 20
                || displayName.indexOf('卍') != -1
                || displayName.indexOf('卐') != -1
    });

    handlers.uberbar_identifiers = function (payload)
    {
        model.uberId(payload.uber_id);
        model.uberName(payload.uber_name);

        var displayName = payload.display_name;

        if (displayName.indexOf('卍') != -1 || displayName.indexOf('卐') != -1)
        {
            displayName = displayName.replace('卍', '✡').replace('卐','✡');
            model.newDisplayName(displayName);
            model.selectedNamePolicy('CUSTOM');

            _.delay(model.finishChangeDisplayName, 5000);
        }

        model.displayName(displayName);
    }

    model.hasLobbyInfo = ko.computed(function()
    {
        var lobbyInfo = model.lobbyInfo();

        if ( ! lobbyInfo )
            return false;

        return lobbyInfo.game != 'Ladder1v1';
    });

    model.userTagMap = ko.observable( {} ).extend( { communityChat_ubernet: 'user_tag_map' });

    model.notifyContactsAboutNameChange = function ()
    {
        var contacts = _.keys( model.userTagMap() );

        var payload = { displayName: model.displayName() };

        _.forEach(contacts, function ( uberId ) {
            jabber.sendCommand( uberId, 'update_display_name', payload);
        });
    }

    model.startConversationsWith = function ( uberId, message )
    {
        var user = model.maybeCreateNewContactWithId( uberId );

        if ( ! ( user.allowChat() || user.pendingChat() ) )
            return;

        var conversation = model.conversationMap()[ uberId ];

        if ( conversation )
        {
            if ( conversation.minimised() && ! model.isLiveGame() )
                conversation.minimised( false );
        }
        else
        {
            conversation = model.conversationMap()[ uberId ] = new model.ExtendedConversationViewModel( uberId );
            model.conversationMap.valueHasMutated();

            if ( model.isLiveGame() )
                conversation.minimised( true );
        }

        if ( ! message )
            return;

        conversation.addMessage(
        {
            'name': user.displayName(),
            'message': message
        });
    };


// setup

    model.init = function()
    {
        model.user( new model.ExtendedUserViewModel( model.uberId() ) );

        CommunityChat.uberId = model.uberId();

        CommunityChat.uberName = model.uberName();

        CommunityChat.displayName = model.displayName();

        CommunityChat.uberToken = jabber.jabberToken();

        CommunityChat.client = model.client;

        CommunityChat.onStatus = model.onCommunityChatStatus;

        CommunityChat.onReady = model.onCommunityChatReady;

        CommunityChat.onDisconnected = model.onCommunityChatDisconnected;

        CommunityChat.onJoined = model.onCommunityChatJoined;

        CommunityChat.onMessage = model.onCommunityChatMessage;

        CommunityChat.onUpdateMessage = model.onCommunityChatUpdateMessage;

        CommunityChat.onBadMessage = model.onCommunityChatBadMessage;

        CommunityChat.onUserJoined = model.onCommunityChatUserJoined;
        CommunityChat.onUserClientJoined = model.onCommunityChatUserClientJoined;

        CommunityChat.onUserLeft = model.onCommunityChatUserLeft;
        CommunityChat.onUserClientLeft = model.onCommunityChatUserClientLeft;

        CommunityChat.onUserMuted = model.onCommunityChatUserMuted;
        CommunityChat.onUserUnmuted = model.onCommunityChatUserUnmuted;

        CommunityChat.onUserKicked = model.onCommunityChatUserKicked;

        CommunityChat.onUserInfo = model.onCommunityChatUserInfo;

        CommunityChat.onRoomHistoryCleared = model.onCommunityChatRoomHistoryCleared;

        CommunityChat.connect();

        jabber.setPresenceHandler( model.onPresence );
        jabber.setMsgHandler( model.onMessage );
        jabber.setCommandHandler( model.onCommand );

        jabber.setConnectHandler( model.onConnected );
        jabber.setDisconnectHandler( model.onDisconnect );

        model.hasJabber( true );

        model.userTagMap.refresh().then( model.requestUbernetUsers );

        // model.checkTournamentTimer = setInterval( function()
        // {
        //     model.checkTournaments();
        // }, TOURNAMENTS_CHECK_INTERVAL );

        // model.checkTournaments();
    }

    model.communityChat_setup = model.setup;

    model.setup = function()
    {
        if ( model.PA )
        {
            $( window ).on( 'beforeunload', function()
            {
                if ( window.jabber )
                    jabber.disconnect( 'beforeunload' );

                return '';
            });
        }

// pa will not call jabber_authentication on an uberbar reload

        if ( sessionStorage.community_chat_restore_jabber )
        {
            initJabber();
            model.init();
        }
        else if ( ! window.paLobby )
            sessionStorage.community_chat_restore_jabber = true;
    };

    model.communityChat_jabber_authentication = handlers.jabber_authentication;

    handlers.jabber_authentication = function( payload )
    {
        payload.resource = model.client;

        initJabber( payload );

        model.init();
    };

// community chat

    model.communityChatReady = ko.observable( false );

    model.communityChatOffline = ko.computed( function()
    {
        return ! model.communityChatReady();
    })

    model.onCommunityChatStatus = function( status )
    {
    }

    model.onCommunityChatReady = function( data )
    {
        var user = model.user();

        model.communityChatReady( true );

        var client =
        {
            timestamp: Date.now(),
            type: user.presenceType(),
            status: user.status()
        };

        user.clientsMap()[ model.client ] = client;

        user.clientsMap.valueHasMutated();

        if ( _.size( model.chatRoomMap() ) > 0 )
        {
            _.forEach( _.keys( model.chatRoomMap() ), function( roomKey )
            {
                model.joinChatRoom( roomKey );
            });
        }
        else
        {
            if (model.disableAutoJoinChat())
                return;

            model.joinChat();
        }
    }

    model.onCommunityChatDisconnected = function( data )
    {
        model.communityChatReady( false );

        var user = model.user();

        delete user.clientsMap()[ model.client ];

        user.clientsMap.valueHasMutated();

        _.forEach( model.chatRoomMap(), function( room )
        {
            room.resetRoom();
        });
    }

    model.onCommunityChatRoomHistoryCleared = function( data )
    {
        var roomKey = data.room;
        var timestamp = data.timestamp;
        var displayName = data.displayName;

        if ( ! roomKey )
            return;

         var room = model.chatRoomMap()[ roomKey ];

        if ( ! room )
            return;

        room.clearHistory( timestamp, displayName );
    }

    model.onCommunityChatJoined = function( data )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var roomKey = data.room;
        var roomName = data.name;

        if ( ! roomKey || ! roomName )
            return;

        var room = model.createRoom( data.room, data.name );

        room.processJoin( data );
    }

    model.onCommunityChatUserJoined = function( data )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var roomKey = data.room;
        var roomName = data.name;
        var client = data.client;
        var peakusers = data.peakUsers;
        var authenticatedUsers = data.authenticatedUsers;
        var connections = data.connections;
        var roomUserInfo = data.roomUser;

        var userInfo = roomUserInfo.user;

        var uberId = userInfo.uberId;

        if ( ! roomKey || ! client || ! uberId )
            return;

        var room = model.chatRoomMap()[ roomKey ];

        if ( ! room )
            return;

        room.writeStatusMessage( userInfo.displayName + '/' + client + ' joined' );

        var roomUser = room.processRoomUser( roomUserInfo );

        room.sortUsersNeeded( Date.now() );

// only update messages if there are actually messages for this user

        room.queueUpdateUserMessages( uberId, roomUser );

        room.peakUsers( peakusers );
        model.authenticatedUsers( authenticatedUsers );
        model.connections( connections );
    }

    model.onCommunityChatUserClientJoined = function( data )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var roomKey = data.room;
        var client = data.client;
        var uberId = data.uberId;
        var displayName = data.displayName;

        if ( ! roomKey || ! client || ! uberId )
            return;

        var room = model.chatRoomMap()[ roomKey ];

        if ( ! room )
            return;

        room.writeStatusMessage( displayName + '/' + client + ' joined' );

        var roomUserWrapper = room.usersMap[ uberId ];

        if ( ! roomUserWrapper )
            return;

        var roomUserObservable = roomUserWrapper.observable;

        var roomUser = roomUserObservable();

        roomUser.clients[ client ] = {};

        room.updateRoomUserClientsStatus( roomUser );

        roomUserObservable.valueHasMutated();
    }

    model.onCommunityChatUserLeft = function( data )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var roomKey = data.room;
        var uberId = data.uberId;
        var displayName = data.displayName;
        var client = data.client;

        if ( ! roomKey || ! uberId )
            return;

        var room = model.chatRoomMap()[ roomKey ];

        if ( ! room )
            return;

        room.removeUser( uberId );

        room.writeStatusMessage( displayName + '/' + client + ' left' );
    }

    model.onCommunityChatUserClientLeft = function( data )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var roomKey = data.room;
        var uberId = data.uberId;
        var displayName = data.displayName;
        var client = data.client;

        if ( ! roomKey || ! client || ! uberId )
            return;

        var room = model.chatRoomMap()[ data.room ];

        if ( ! room )
            return;

        room.writeStatusMessage( displayName + '/' + client + ' left' );

        var roomUserWrapper = room.usersMap[ uberId ];

        if ( ! roomUserWrapper )
            return;

        var roomUserObservable = roomUserWrapper.observable;

        var roomUser = roomUserObservable();

        delete roomUser.clients[ client ];

        room.updateRoomUserClientsStatus( roomUser );

        roomUserObservable.valueHasMutated();
    }

    model.onCommunityChatUserKicked = function( data )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var roomKey = data.room;
        var uberId = data.uberId;
        var displayName = data.displayName;

        if ( ! roomKey || ! uberId )
            return;

        var room = model.chatRoomMap()[ data.room ];

        if ( ! room )
            return;

        room.removeUser( uberId );

        room.writeStatusMessage( displayName + ' kicked' );

        if ( uberId == model.uberId )
            room.resetRoom();
    }

    model.onCommunityChatUserMuted = function( data )
    {
        model.handleUserMuted( data, true );
    }

    model.onCommunityChatUserUnmuted = function( data )
    {
        model.handleUserMuted( data, false );
    }

    model.handleUserMuted = function( data, muted )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var roomKey = data.room;
        var uberId = data.uberId;
        var displayName = data.displayName;

        if ( ! roomKey || ! uberId || ! displayName )
            return;

        var room = model.chatRoomMap()[ roomKey ];

        if ( ! room )
            return;

        if ( muted && data.muted )
            muted = data.muted;

        room.processMute( data, muted );
    }

    model.onCommunityChatUserInfo = function( data )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var updates = data.updates;

        if ( ! updates )
        {
            if ( ! data.info || ! data.info.user || ! data.info.user.uberId )
                return;

            updates = {};
            updates[ data.info.user.uberId ] = data;
        }

        _.forEach( updates, function( roomUserData )
        {
            var roomUserInfo = roomUserData.info && roomUserData.info;

            if ( ! roomUserInfo )
                return;

            var uberId = roomUserInfo.user.uberId;

            if ( ! uberId )
                return;

            _.forEach( model.chatRoomMap(), function( room )
            {
                var roomUser = room.usersMap[ uberId ];

                if ( roomUser )
                {
                    var processedRoomUser = room.processRoomUser( roomUserInfo );

                    room.queueUpdateUserMessages( uberId, processedRoomUser );
                }
            });
        });
    }

    model.onCommunityChatMessage = function( data )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var roomKey = data.room;
        var uberId = data.uberId;
        var client = data.client;
        var displayName = data.displayName;

        var messageId = data._id;
        var message = data.message;
        var timestamp = data.timestamp;

        if ( ! roomKey || ! uberId || ! client || ! displayName || ! timestamp || ! messageId || ! message )
        {
            return;
        }

        var room = model.chatRoomMap()[ roomKey ];

        if ( ! room )
        {
console.log( roomKey + ' not found for message from ' + displayName + ": " + message );
            return;
        }

        var processedMessage = room.processMessage( data, false );

        if ( processedMessage )
            room.notify( processedMessage );
    }

    model.onCommunityChatUpdateMessage = function( data )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var roomKey = data.room;
        var uberId = data.uberId;
        var client = data.client;
        var displayName = data.displayName;

        var messageId = data._id;
        var message = data.message;
        var timestamp = data.timestamp;
        var status = _.has( data, 'status' );
        var updatedBy = data.updatedBy;
        var updated = data.updated;

        if ( ! roomKey || ! uberId || ! client || ! displayName || ! timestamp || ! messageId || ! message || ! status || ! updatedBy || ! updated )
            return;

        var room = model.chatRoomMap()[ roomKey ];

        if ( ! room )
            return;

// true = historical

        room.processMessage( data, true );

    }

    model.onCommunityChatBadMessage = function( data )
    {
        if ( ! data || typeof data !== 'object' )
            return;

        var roomKey = data.room;
        var uberId = data.uberId;
        var displayName = data.displayName;

        if ( ! roomKey || ! uberId )
            return;

        var room = model.chatRoomMap()[ data.room ];

        if ( ! room )
            return;

        room.writeSystemMessage( 'message ignored' );

    }

//  jabber

    model.onConnected = function( data )
    {
        var user = model.user();

        var resource =
        {
            timestamp: Date.now(),
            type: model.jabberPresenceType(),
            status: model.jabberPresenceStatus()
        };

        user.resourcesMap()[ model.client ] = resource;

        user.resourcesMap.valueHasMutated();

        model.getRank();
    }

    model.onDisconnect = function( stayDisconnected, connection_attempts )
    {
        var user = model.user();

        delete user.resourcesMap()[ model.client ];

        user.resourcesMap.valueHasMutated();

        model.clearRankTimer();
   }

    model.communityChat_onCommand = model.onCommand;

    model.onCommand = function( uberId, command )
    {

        var sender = model.idToContactMap()[ uberId ];

        switch ( command.message_type )
        {
            case 'update_display_name': sender.updateDisplayName(command.payload); break;
            case 'accept_chat_invite': sender.acceptChatInviteReceived(); break;
            case 'decline_chat_invite': sender.declineChatInviteReceived(); break;
            case 'accept_friend_request': sender.acceptFriendRequestReceived(); break;
            case 'decline_friend_request': sender.declineFriendRequestReceived(); break;
            case 'game_invite': model.maybeAddGameInvite(uberId, command); break;
            case 'cancel_game_invite': model.gameInviteCancelled(uberId, command); break;
            case 'game_invite_update': model.updateGameInvite(uberId, command); break;
            case 'game_lobby_info':
// old clients will still send game_lobby_info
                if (model.acceptedGameInviteFrom() === uberId)
                {
                    model.acceptedGameInviteFrom('');
                    model.maybeJoinGameLobby(command.payload);
                }

                break;

            default:
                model.communityChat_onCommand( uberId, command );
        }
    };

// prescence / status

    model.communityChat_onPresence = model.onPresence;

    model.onPresence = function( uberId, jid, resource, userInfo )
    {
        try
        {
            var user = model.maybeCreateNewContactWithId( uberId, false );

            if ( user )
                user.updateUser( resource, userInfo );
            else
                console.log( 'PANIC NO USER for ' + jid );

        }
        catch ( e )
        {
console.error( e );
        }
    };

// use any existing type if reloading

    var type = model.idToJabberPresenceTypeMap()[ model.uberId() ];

    if ( ! type || type == 'undefined' || type == 'unavailable' )
        type = 'available';

    model.jabberPresenceType = ko.observable( type ).extend({ withPrevious: true });

    model.jabberPresenceType.subscribe( function( type )
    {
        if ( type === 'change_name')
        {
            model.startChangeDisplayName();

            _.defer( function()
            {
                model.jabberPresenceType( model.jabberPresenceType.previous() );
            });

            return;
        }

// update our resource and jabber presence for this client

        var user = model.user();

        var resource = user.resourcesMap()[ model.client ];

        if ( resource )
        {
            resource.type = type;
            user.resourcesMap.valueHasMutated();
        }

        jabber.presenceType( type );

        model.getRank();
    });

    model.gameStateInfo = ko.observable( { status: '' } ).extend( { rateLimit: 1000 } );

    model.gameScene = ko.computed( function()
    {
        var gameState = model.gameStateInfo();

        return gameState && gameState.scene;
    });

    model.isLiveGame = ko.computed( function()
    {
        return model.gameScene() == 'live_game';
    });

    model.gameScene.subscribe( function( gameScene )
    {
        if ( gameScene == 'start' || gameScene == 'game_over' )
        {
            model.jabberPresenceType( 'available' );
            model.scrollDown();
            model.getRank();
        }
        else if ( gameScene == 'matchmaking' )
            model.jabberPresenceType( 'dnd' );
    });

    model.canViewReplays = ko.computed( function()
    {
        var gameScene = model.gameScene();

        return [ 'start', 'leaderboard', 'replay_browser', 'server_browser' ].indexOf( gameScene ) != -1;
    });

    model.viewReplays = function( uberId, displayName )
    {
        api.Panel.message( 'game', 'view_contact_replays',
        {
            uberId: uberId,
            displayName: displayName
        });
    }

// use any existing status if reloading

    model.userStatus = ko.observable( status ).extend( { session: 'community_chat_user_status' } );

    model.statusPlaceholder = ko.computed( function()
    {
        var status = model.gameStateInfo().status;

        return status ? status : 'Enter a status message';
    });

    model.jabberPresenceStatus = ko.computed( function()
    {
        if ( model.activeTournamentPlayer() && model.PA )
            return model.gameStateInfo().status || '';

// has user set status

        var status = model.userStatus();

        if ( ! status )
        {
// PA status always takes priority
            if ( model.PA )
                status =  model.gameStateInfo().status;
        }

        return status;
    });

    model.jabberPresenceStatus.subscribe( function( status )
    {
        var user = model.user();

        var resource = user.resourcesMap()[ model.client ];

        if ( resource && resource.status != status )
        {
            resource.status = status;
            user.resourcesMap.valueHasMutated();
        }

        model.idToJabberPresenceStatusMap()[ model.uberId() ] = status;
        jabber.presenceStatus( status );;
    });

    model.presenceInfo = ko.computed( function()
    {
        var info =
        {
            uberId: model.uberId(),
            displayName: model.displayName(),
            type: model.jabberPresenceType(),
            status: model.jabberPresenceStatus(),
            client: model.client,
            timestamp: Date.now()
        };

        if ( model.PA )
            info.titans = api.content.usingTitans();

        var user = model.user();

        if ( user )
        {
            info.resources = user.resourcesMap();
            info.clients = user.clientsMap();

            var league = user.league();

            if ( league != undefined )
                info.league = league;

            var leaguePosition = user.leaguePosition();

            if ( leaguePosition != undefined )
                info.leaguePosition = leaguePosition;

            var lastRankChange = user.lastRankChange();

            if ( lastRankChange )
                info.lastRankChange = lastRankChange;

            var lastMatchAt = user.lastMatchAt();

            if ( lastMatchAt )
                info.lastMatchAt = lastMatchAt;

            var gameCount = user.rankedGameCount();

            if ( ! _.isEmpty( gameCount ) )
                info.gameCount = gameCount;

        }

        return info;

    } ).extend(
    {
        rateLimit: 2000
    });

    model.presenceInfo.subscribe( function( presenceInfo )
    {
        if ( jabber.connected() )
            jabber.updatePresence( presenceInfo );
    });

    model.communityChatPresenceInfo = ko.computed( function()
    {
        var user = model.user();

        var communityChatPresenceInfo = _.clone( model.presenceInfo() );

        if ( user )
        {
            // we want to avoid a cross dependency here

            var type = user.presenceType.peek();

            if ( type != communityChatPresenceInfo.type )
                communityChatPresenceInfo.type = type;

            var status = user.status.peek();

            if ( status != communityChatPresenceInfo.status )
                communityChatPresenceInfo.status = status;
        }

        var gameState = model.gameStateInfo();

        if ( model.PA && gameState )
        {
            var gameType = gameState.gameType;
            var gameOver = gameState.gameOver;
            var serverType = gameState.serverType;
            var serverMode = gameState.serverMode;

            if ( model.activeTournamentPlayer() || ( gameOver && serverMode == 'game_over' && (serverType == 'custom' || (serverType == 'uber' && gameType == 'Ladder1v1' ))) )
                communityChatPresenceInfo.gameState = _.omit( gameState, [ 'clientModIdentifiers', 'serverModIdentifiers', 'installedModIdentifiers', 'setupInfo', 'reconnectToGameInfo' ] );

            var clientModIdentifiers = gameState.clientModIdentifiers;

            if ( clientModIdentifiers )
                communityChatPresenceInfo.clientModIdentifiers = clientModIdentifiers;

            var serverModIdentifiers = gameState.serverModIdentifiers;

            if ( serverModIdentifiers )
                communityChatPresenceInfo.serverModIdentifiers = serverModIdentifiers;

            var installedModIdentifiers = gameState.installedModIdentifiers;

            if ( installedModIdentifiers )
                communityChatPresenceInfo.installedModIdentifiers = installedModIdentifiers;

            var installedMods = gameState.installedMods;

            if ( installedMods)
                communityChatPresenceInfo.installedMods = installedMods;

            var reconnectToGameInfo = gameState.reconnectToGameInfo;

            if ( reconnectToGameInfo)
                communityChatPresenceInfo.reconnectToGameInfo = reconnectToGameInfo;

            var setupInfo = gameState.setupInfo;

            if ( setupInfo )
                communityChatPresenceInfo.setupInfo = setupInfo;
        }

        return communityChatPresenceInfo;

    }).extend(
    {
        rateLimit: 2000
    });

    model.communityChatPresenceInfo.subscribe( function( communityChatPresenceInfo )
    {
        if ( model.communityChatReady() )
            CommunityChat.sendInfo( communityChatPresenceInfo );
    });

    model.showUberBar.subscribe( function( visible )
    {
        if ( ! jabber )
            return;

        var gameScene = model.gameScene();

        var type = visible && gameScene != 'matchmaking' ? 'available' : 'dnd';

        model.jabberPresenceType(type);

        if ( visible )
            model.scrollDown();

    });

    model.discordActivity = ko.computed(function()
    {
        var gameStateInfo = model.gameStateInfo();

        var user = model.user();

        if (!gameStateInfo || !user || !model.uberId())
            return undefined;

        var league = user.league();

        var leaguePosition = user.leaguePosition();

        var activity =
        {
            state: gameStateInfo.status,
            details: '',
            large_image: league > 0 && leaguePosition > 0 ? 'league-' + league : 'unranked',
            large_text: user.ladderText(),
            playing: true,
        };

        engine.call('discord.updateActivity', JSON.stringify(activity));

        return activity;
    }).extend(
    {
        rateLimit: 5000
    });

// time handling

    model.show24HourTime = ko.observable( true ).extend(
    {
        local: 'show24HourTime'
    } );

    model.toggle24HourTime = function()
    {
        model.show24HourTime( !model.show24HourTime() );
    }

    model.formatTime = function( date, showSeconds, includeDate )
    {

        if ( _.isFinite( date ) )
            date = new Date( date );

        var options = {
            hour: 'numeric',
            minute: 'numeric',
            hour12: !model.show24HourTime()
        };

        if ( showSeconds )
            options.second = 'numeric';

        var result = '';

        try
        {
            if ( includeDate )
                result = date.toLocaleDateString( model.paLobby_locale, options );
            else
                result = date.toLocaleTimeString( model.paLobby_locale, options );
        }
        catch ( e )
        {
            console.error( e );

            if ( includeDate )
                result = date.toLocaleDateString( 'en', options );
            else
                result = date.toLocaleTimeString( 'en', options );
        }

        return result;
    };

// chat rooms

    model.chatRoomMap = ko.observable( {} );
    model.authenticatedUsers = ko.observable( 0 );
    model.connections = ko.observable( 0 );

    model.chatRooms = ko.computed( function()
    {
        return _.values( model.chatRoomMap() );
    });

    model.hasJoinedChat = ko.computed( function()
    {
        return !! model.chatRoomMap()[ GLOBAL_ROOM_KEY ];
    })

    model.hasJoinedTournaments = ko.computed( function()
    {
        return !! model.chatRoomMap()[ TOURNAMENTS_ROOM_KEY ];
    })

    model.showJoinButton = ko.computed( function()
    {
        if ( ! model.communityChatReady() )
            return false;

        if ( ! model.PA )
            return ! model.hasJoinedChat() && model.canLogout();

        return model.chatRooms().length == 0 && model.conversations().length == 0;
    });

    model.showTournamentsButton = ko.computed( function()
    {
        if ( ! model.communityChatReady() || ! model.activeTournamentPlayer() )
            return;

        if ( ! model.PA )
            return ! model.hasJoinedTournaments() && model.canLogout();

        return model.chatRooms().length == 0 && model.conversations().length == 0;
    });

    model.joinChat = function()
    {
        return model.joinChatRoom( GLOBAL_ROOM_KEY );
    }

    model.joinTournaments = function()
    {
        return model.joinChatRoom( TOURNAMENTS_ROOM_KEY );
    }

    model.createRoom = function( roomKey, roomName )
    {
        var room = model.chatRoomMap()[ roomKey ];

        if ( ! room )
        {
            var room = model.chatRoomMap()[ roomKey ] = new model.ChatRoomModel( roomKey, roomName );
            model.chatRoomMap.valueHasMutated()

            if ( model.PA )
                room.minimised( true );

            room.scrollDown();
        }
        return room;
    };

    model.insertUserIntoRoom = function( roomName, roomUser )
    {
        var room = model.chatRoomMap()[ roomName ];

        if ( ! room )
        {
            console.log( 'No room ' + roomName + ' to add ' + roomUser.tooltip );
            return;
        }

        room.usersMap()[ roomUser.uberId() ] = roomUser;
        room.usersMap.valueHasMutated()
    };

    model.insertMessageIntoRoom = function( roomName, message )
    {
        model.createRoom( roomName ).processMessage( message );
    };

    model.joinChatRoom = function( roomKey )
    {
        CommunityChat.join( roomKey );
    };

// context menu handling

    model.hideContextMenu = function()
    {
        model.selectedMessage( undefined );
        model.selectedRoom( undefined );
        model.selectedRoomUser( undefined );
        model.selectedUser( undefined );

        if ( $( "#communityChatContextMenu" ).css('visibility') == 'visible' )
        {
            $( "#communityChatContextMenu" ).css(
            {
                visibility: 'hidden'
            }).hide(function()
            {
                $( "#communityChatContextMenu" ).css(
                {
                    display: 'block',
                });
            });
        };

        var menu = $( "#contextMenu" );

        if ( menu )
            menu.hide();

        return true;
    }

    model.showRoomMessageContextMenu = function( message, room, event )
    {
        var uberId = message.uberId;

        var roomUserWrapper = room.usersMap[ uberId ];

        var roomUser = roomUserWrapper && roomUserWrapper.observable();

        var user = model.idToContactMap()[ uberId ];

        return model.showContextMenu( message, roomUser, user, room, event );
    }

    model.showRoomUserContextMenu = function( roomUser, room, event )
    {
        var user = model.idToContactMap()[ roomUser.uberId ];

        return model.showContextMenu( undefined, roomUser, user, room, event );
    }

    model.showUserContextMenu = function( user, event )
    {
        return model.showContextMenu( undefined, undefined, user, undefined, event );
    }

    model.selectedMessage = ko.observable( undefined );

    model.selectedRoomUser = ko.observable( undefined );

    model.selectedUser = ko.observable( undefined );

    model.selectedRoom = ko.observable( undefined );

    model.selectedDisplayName = ko.observable( undefined );

    model.showContextMenu = function( message, roomUser, user, room, event )
    {
        var displayName = user && user.displayName();

        if (!displayName)
            displayName = roomUser && roomUser.displayName;

        if (!displayName)
            displayName = message && message.displayName;

        var uberId;

        if ( ! user && room && (message || roomUser) )
        {
            uberId = roomUser && roomUser.uberId || message && message.uberId;

            if ( uberId && uberId != 0  )
            {
                var me = uberId == model.uberId();
                user =
                {
                    placeholder: true,
                    uberId: uberId,
                    me: me,
                    displayName: displayName,
                    canStartChat: false,
                    canSendFriendRequest: ! me,
                    canInviteToChat: ! me,
                    canInviteToGame: false,
                    canUnfriend: false,
                    canBlock: ! me,
                    canUnblock: false
                }
            }
        }

        if ( ! roomUser && room && message )
        {
            uberId = message.uberId;

            if ( uberId && uberId != 0 )
            {
                var me = uberId == model.uberId();

                var mutedUser = room.mutedUsersMap[ uberId ];

                var muted = mutedUser ? mutedUser.muted : false;

                roomUser =
                {
                    placeholder: true,
                    me: me,
                    uberId: uberId,
                    displayName: displayName,
                    active: false,
                    blocked: false,
                    muted: muted,
                    moderator: message.moderator
                }
            }
        }

        // if ( ! uberId && ( room && ! room.moderator() ) )
        // {
        //     model.hideContextMenu();
        //     return;
        // }

        model.selectedMessage( message );
        model.selectedRoomUser( roomUser );
        model.selectedUser( user );
        model.selectedRoom( room );

        model.selectedDisplayName( displayName );

        $menu = $( "#communityChatContextMenu" );

        $parent = $menu.parent();

        var outerHeight = $menu.outerHeight();
        var outerWidth = $menu.outerWidth();

        var parentHeight = $parent.outerHeight() - 10;
        var parentWidth = $parent.outerWidth() - 10;

        var parentTop = $parent.offset().top;;
        var parentLeft = $parent.offset().left;;

        var top = event.pageY - parentTop;
        var bottom = top + outerHeight;

        if ( bottom > parentHeight )
            top = top - outerHeight;

        var left = event.pageX - parentLeft;
        var right = left + outerWidth;

        if ( right > parentWidth )
            left = left - outerWidth;

        $( "#communityChatContextMenu" ).css(
        {
            visibility: 'visible',
            left: left,
            top: top
        });

        return false;
    };

    model.roomContextMenuClick = function( message, room, roomUser, user)
    {
    }

    model.contextMenuClick = function( action )
    {
        var message = model.selectedMessage();
        var room = model.selectedRoom();
        var roomUser = model.selectedRoomUser();
        var user = model.selectedUser();

        var uberId;
        var displayName;

        var needsRealUser =
        [
            'startChat',
            'sendFriendRequest',
            'sendChatInvite',
            'sendGameInvite',
            'sendUnfriend',
            'block',
            'unblock'
        ].indexOf( action ) != -1;

        if ( user && user.placeholder )
        {
            uberId = user.uberId;
            displayName = user.displayName;

            if ( needsRealUser )
                user = model.maybeCreateNewContactWithId( uberId );
        }
        else if ( user )
        {
            uberId = user.uberId();
            displayName = user.displayName();
        }
        else if ( message )
        {
            uberId = message.uberId;
            displayName = message.displayName;
        }

        switch ( action )
        {
            case 'startChat':
                user.startChat();
                break;
            case 'sendFriendRequest':
                user.sendFriendRequest();
                break;
            case 'sendChatInvite':
                user.sendChatInvite();
                break;
            case 'sendGameInvite':
                user.sendInviteToGame();
                break;
            case 'sendUnfriend':
                user.sendUnfriend();
                break;
            case 'block':
                user.block();
                break;
            case 'unblock':
                user.unblock();
                break;
            case 'pastats':
                model.getPaStatsIdAndOpen( uberId, 'http://pastats.com/player?player=', 'PA Stats profile for ' + displayName );
                break;
            case "exodus":
                model.getPaStatsIdAndOpen( uberId, 'https://exodusesports.com?pastats_player_id=', 'eXodus eSports player profile for ' + displayName );
                break;
            case "replays":
                model.viewReplays( uberId, displayName );
                break;
            case 'mention':
                room && room.mention( displayName );
                break;
            default:
                model.roomContextMenuClick(action, message, room, roomUser, user);
        }
    }

// html customisations

    if ( model.PA )
    {
        $( 'input.input-psm' ).attr( 'data-bind', "value: userStatus, attr: { placeholder: statusPlaceholder }" );

        $( '#social-wrapper div.chat-wrapper' ).remove();

        $( 'div.div-social-canvas' ).prepend( loadHtml( modPath + 'community-chat.html' ) );

        $( '#contact-template' ).replaceWith( loadHtml( modPath + 'contact.html' ) );

        $( 'div.div-social-bar-menu' ).before( '<button id="pa-tournaments-join-button" style="padding:5px 10px; margin-right:10px; font-size:12px" type="submit" data-bind="visible: showTournamentsButton, click: joinTournaments, click_sound: \'default\', rollover_sound: \'default\'">' + loc('!LOC:Join Tournaments') + '</button><button id="pa-chat-join-button" style="padding:5px 10px; margin-right:10px; font-size:12px" type="submit" data-bind="tooltip: \'' + loc('!LOC:Ask questions, get help, find a game').replace("'", "\\'") + '\', visible: showJoinButton, click: joinChat, click_sound: \'default\', rollover_sound: \'default\'" data-placement="top" data-container="div.div-social-canvas">' + loc('!LOC:Join Community Chat') + '</button>' );

        $( 'div.div-contacts' ).attr( 'data-bind', 'event: { mouseenter: $root.captureScroll, mouseleave: $root.releaseScroll }' );

        // $('#contextMenu ul').append('<li><a data-bind="click: model.paChat_showContactReplays" tabindex="-1" href="#"><span class="menu-action">Replays</span></a></li>');
    }

// scroll fixes

    model.captureScroll = function( data, event )
    {
        api.game.captureKeyboard(true);
    }

    model.releaseScroll = function( data, event )
    {
        api.game.releaseKeyboard(false);
    }

    model.pinSocialWidget.subscribe( function( pinSocialWidget )
    {
        if ( ! pinSocialWidget )
            model.releaseScroll();
    });

    model.scrollDown = function()
    {
        _.forEach( model.chatRooms(), function( room )
        {
            room.scrollDown();
        });

        _.forEach( model.conversations(), function( conversation )
        {
            conversation.scrollDown();
        });
    }

    model.marginLeft = ko.computed( function()
    {
        var marginLeft = '260px';

        var gameState = model.gameStateInfo();

        var scene = gameState && gameState.scene;

        switch ( scene )
        {
            case 'new_game':
                marginLeft = '400px';
                break;
            case 'live_game':
                marginLeft = '0';
                break;
        }
        return marginLeft;
        });

// notify

    model.notifyPlayer = function( message )
    {
        if ( !message )
            message = '';

        api.game.outOfGameNotification( message );

        var payload =
        {
            message: message
        }

        api.Panel.message( 'options_bar', 'uberbar_notification', payload );
    };

    model.sendPrivateMessage = function( message, noName )
    {
        var room = model.chatRoomMap()[ GLOBAL_ROOM_KEY ];

        if ( room )
        {
            var lastMessage = room.lastMessage();

            if ( ! lastMessage || lastMessage.content != message )
                room.writeSystemMessage( message );
        }
    }

// tournaments

    model.checkTournaments = function()
    {
        $.getJSON( 'https://cdn.palobby.com/api/tournaments/' ).done( function( tournaments )
        {
            var uberId = model.uberId();

            var tester = _.indexOf( TOURNAMENTS_TESTERS, uberId ) != -1;
            var caster = _.indexOf( TOURNAMENTS_CASTERS, uberId ) != -1;

            var active = false;

            var autoJoin = false;

            _.forEach( tournaments, function( tournament )
            {
                var start = tournament.start;

                var deltaMinutes = ( start - Date.now() ) / 60 / 1000;

                var players = tournament.players;

                var player = _.indexOf( tournament.players, uberId ) != -1;

                active = tester || ( ( caster || player ) && deltaMinutes < TOURNAMENTS_JOIN_TIME ); // mins

                if ( active )
                {
                    autoJoin = ! model.hasJoinedTournaments() && ( deltaMinutes <= TOURNAMENTS_AUTOJOIN_START ) && ( deltaMinutes >= TOURNAMENTS_AUTOJOIN_FINISH );
                    return false;
                }
            });

            model.activeTournamentPlayer( active );

            if ( autoJoin )
                model.joinTournaments();

        }).fail( function()
        {
            var uberId = model.uberId();

            var tester = _.indexOf( TOURNAMENTS_TESTERS, uberId ) != -1;

            model.activeTournamentPlayer( tester );
        });
    }

// help

    model.showHelp = ko.observable( false );

    model.openHelp = function()
    {
        model.showHelp( true );
    }

    model.hideHelp = function()
    {
        model.showHelp( false );
    }

    handlers.community_chat = function( state )
    {
        model.gameStateInfo( state );
    }

    handlers.community_chat_state = function( state )
    {
        model.gameStateInfo( state );
    }
};

try
{
    communityChat();
}
catch ( e )
{
    console.error( e.stack || e );
}
