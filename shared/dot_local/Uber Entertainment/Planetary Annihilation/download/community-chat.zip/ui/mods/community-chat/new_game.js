var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( 'Community Chat new_game already loaded' );
        return;
    }

    paChatLoaded = true;

    console.log( 'Community Chat new_game' );

    model.community_chat_state = ko.computed( function()
    {
        var state = { status: '' };

        try
        {

            var lobbyId = model.lobbyId();

            var gameType = model.gameType();

            var type = gameType;

            var isGameCreator = model.isGameCreator();

            var isTeamGame = model.isTeamGame();

            var isPublicGame = model.isPublicGame();

            var emptySlots = model.numberOfEmptySlots();

            var requiredContent = model.requiredContent();

            var spectatorLimit = model.spectatorLimit();

            var spectatorCount = model.playersWithoutArmies().length;

            var emptySpectatorSlots = spectatorLimit - spectatorCount;

            var serverModIdentifiers = model.gameModIdentifiers();

            var gameName = model.gameName();

            var sandbox = model.sandbox();

            var suddenDeathMode = model.suddenDeathMode();

            switch ( gameType )
            {
                case 'FreeForAll':
                    type = 'FFA';
                    break;
                case 'TeamArmies':
                    type = 'Team';
                    break;
                case 'Galactic War':
                    type = 'GW';
                    break;
                case 'Ladder1v1':
                    type = 'Ranked';
                    break;
            }

            var system = model.system() ? model.system().name : '';

            var playerCount = model.playerCount();

            var armies = model.armies();

            var format = '';

            var shared = false;

            var counts = [];

            var players = [];

            _.forEach( armies, function( army )
            {
                var slots = army.slots();

                counts.push( slots.length );

                if ( ! army.alliance() )
                {
                    shared = true;
                }

                _.forEach( slots, function( slot, index )
                {
                    if ( slot.isPlayer() )
                    {
                        var player =
                        {
                            playerId: slot.playerId(),
                            playerName: slot.playerName(),
                            ai: slot.ai(),
                            economyFactor: slot.economyFactor(),
                            armyIndex: army.index(),
                            slotIndex: index,
                        }

                        players.push( player );
                    }
                });
            });

            if ( playerCount > 1 )
            {
                if ( playerCount == 2 )
                {
                    format = '1v1';

                    if ( type == 'Ranked' )
                    {
                        format = format + ' ' + type;
                    }
                }
                else
                {
                    format = playerCount + ' ' + type;
                }

                if ( isTeamGame )
                {
                    if ( playerCount > 2 )
                    {
                        format = counts.join( 'v' ) + ' ' + ( shared ? 'shared' : 'unshared' );
                    }
                }

            }

            var classic = system && requiredContent && requiredContent.length == 0;

            var role = isGameCreator ? 'Hosting' : 'Joined';

            var status = role + ( isPublicGame ? '' : ' private' ) + ( classic ? ' Classic' : '' ) + ' ' + format + ( system ? ' on ' + system : '' );

            var lobbyStatus = '';

            if ( playerCount > 2 && emptySlots > 0 )
            {
                lobbyStatus = emptySlots + ' more';
            }

            if ( spectatorLimit > 0 )
            {
                lobbyStatus = lobbyStatus + ' with ' + spectatorCount + '/' + spectatorLimit + ' spectators';
            }

            if ( lobbyStatus )
            {
                status = status + ' (' + lobbyStatus + ')';
            }

            state =
            {
                scene: 'new_game',
                lobbyId: lobbyId,
                gameType: gameType,
                isGameCreator: isGameCreator,
                isPublicGame: isPublicGame,
                system: system,
                format: format,
                emptySlots: emptySlots,
                playerCount: playerCount,
                spectatorLimit: spectatorLimit,
                spectatorCount: spectatorCount,
                requiredContent: requiredContent,
                gameName: gameName,
                role: role,
                status: status,
                lobbyStatus : lobbyStatus,
                players: players,
                serverModIdentifiers: serverModIdentifiers,
                sandbox: sandbox,
                suddenDeathMode: suddenDeathMode,
                reconnectToGameInfo: model.reconnectToGameInfo(),
                timestamp: Date.now()
            }

            api.Panel.message( 'uberbar', 'community_chat_state', state );

        }
        catch ( e )
        {
            console.error( e );
        }

        return state;

    }).extend(
    {
        rateLimit: 2000
    });
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}