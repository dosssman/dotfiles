var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( 'Community Chat connect_to_game already loaded' );
        return;
    }

    paChatLoaded = true;

    console.log( 'Community Chat connect_to_game' );

    ko.computed( function()
    {
        var pageTitle = model.pageTitle();
        var pageSubTitle = model.pageSubTitle();

        var reconnectToGameInfo = model.reconnectToGameInfo();

        var status = pageSubTitle || pageTitle;

        if (reconnectToGameInfo && reconnectToGameInfo.type == 'Ladder1v1')
            status = 'Playing 1v1 Ranked';

        var state =
        {
            scene: 'connect_to_game',
            status: status,
            pageTitle: pageTitle,
            pageSubTitle: pageSubTitle,
            reconnectToGameInfo: reconnectToGameInfo,
            timestamp: Date.now()
        }

        api.Panel.message( 'uberbar', 'community_chat_state', state );
    }).extend(
    {
        rateLimit: 1000
    });
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}