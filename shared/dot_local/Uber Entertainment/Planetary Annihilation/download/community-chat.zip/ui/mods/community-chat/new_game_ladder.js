var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( 'Community Chat new_game_ladder already loaded' );
        return;
    }

    paChatLoaded = true;

    console.log( 'Community Chat new_game_ladder' );

    var state =
    {
        scene: 'new_game_ladder',
        gameType: 'Ladder1v1',
        status : 'Playing 1v1 Ranked',
        timestamp: Date.now()
    }

    api.Panel.message( 'uberbar', 'community_chat_state', state );
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}