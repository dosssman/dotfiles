var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( 'Community Chat load_planet already loaded' );
        return;
    }

    paChatLoaded = true;

    console.log( 'Community Chat load_planet' );

    ko.computed( function()
    {
       var state =
       {
           scene: 'load_planet',
           status: 'Selecting System',
           timestamp: Date.now()
       }

       api.Panel.message( 'uberbar', 'community_chat_state', state );
    });
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}