var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( 'Community Chat start already loaded' );
        return;
    }

    paChatLoaded = true;

    console.log( 'Community Chat start' );

    if ( ! globalHandlers.view_contact_replays )
    {
        globalHandlers.view_contact_replays = function( payload )
        {
            if ( ! payload.uberId )
                return false;

            var params = '?uberId=' + payload.uberId;

            if ( payload.displayName )
                params = params + '&displayName=' + encodeURIComponent(payload.displayName);

            window.location.href = 'coui://ui/main/game/replay_browser/replay_browser.html' + params;

            return true;
        }
    }

    ko.computed( function()
    {
        var state =
        {
            scene: 'start',
            status: '',
            reconnectToGameInfo: model.reconnectToGameInfo(),
            timestamp: Date.now()
        }

        var setupInfo = model.setupInfo();

        if ( setupInfo )
        {
            setupInfo = _.clone( setupInfo );

            setupInfo.localServerSetting = model.localServerSetting();

            setupInfo.region = model.uberNetRegion();

            setupInfo.usingTitans = api.content.usingTitans();
            setupInfo.ownsTitans = api.content.ownsTitans();
            setupInfo.titansWasKSGift = api.content.titansWasKSGift();

            setupInfo.pammDetected = window.CommunityModsManager && CommunityModsManager.pammDetected();

            setupInfo.timestamp = Date.now();

            state.setupInfo = setupInfo;
        }

        if (window.CommunityModsManager)
        {
            state.clientModIdentifiers = CommunityModsManager.activeClientModIdentifiers();
            state.serverModIdentifiers = CommunityModsManager.activeServerModIdentifiers();
            state.installedModIdentifiers = _.keys(CommunityModsManager.installedModsIndex());
            state.installedMods = _.map(CommunityModsManager.installedMods(), function( mod ) { return _.omit( mod, ['unitList']) } );
        }

        api.Panel.message( 'uberbar', 'community_chat', state );
    });
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}