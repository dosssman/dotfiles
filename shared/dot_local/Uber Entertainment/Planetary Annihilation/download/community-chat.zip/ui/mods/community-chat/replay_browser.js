var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( 'Community Chat replay_browser already loaded' );
        return;
    }

    paChatLoaded = true;

    console.log( 'Community Chat replay_browser' );

    if ( ! globalHandlers.view_contact_replays )
    {
        globalHandlers.view_contact_replays = function( payload )
        {

            if ( !payload.uberId )
                return false;

            var params = '?uberId=' + payload.uberId;

            if ( payload.displayName )
                params = params + '&displayName=' + encodeURIComponent(payload.displayName);

            window.location.href = 'coui://ui/main/game/replay_browser/replay_browser.html' + params;

            return true;
        }
    }

    if ( ! model.otherUberId )
    {
        loadScript( 'coui://ui/main/shared/js/leaderboard_utility.js' );

        $( '#replay-list-scope' ).replaceWith( '<select class="selectpicker form-control" id="replay-list-scope" name="game-state" data-bind="options: replayListScopeOptions, optionsText: \'text\', optionsValue: \'value\', selectPicker: replayListScope"></select>' );

        model.otherUberId = ko.observable('');
        model.otherDisplayName = ko.observable('');
        model.otherUberId.subscribe(function()
        {
            LeaderboardUtility.getPlayerDisplayName( model.otherUberId() ).subscribe(function( displayName )
            {
                model.otherDisplayName( displayName );
            })
        });

        model.replayListScope = ko.observable('');

        model.replayListScopeOptions = ko.computed( function()
        {
            var options =
            [
                {
                    text: loc('All Recent Games'),
                    value: ''
                },
                {
                    text: loc('My Games Only'),
                    value: model.uberId()
                }
            ];

            if ( model.otherUberId() )
                options.unshift(
                {
                    text: model.otherDisplayName(),
                    value: model.otherUberId()
                });

            return options;
        });

        model.updateReplayData = function()
        {
            api.net.getReplays( model.replayListSortOrder(), model.replayListScope() ).done( function (data)
            {
               var startingGameListSize = model.gameList().length;

                newGameList = [];

                try
                {
                    data = JSON.parse( data );

                    var games = data.Games;

                    if ( data.Status !== 'Ready' )
                    {
                        games = [];
                        model.titleSuffix( loc( '!LOC: (Updating...)' ) );
                        setTimeout( model.updateReplayData, 1000);
                    }
                    else
                        model.titleSuffix( '' );

                }
                catch ( e )
                {
                    return;
                }

                for ( var i = 0; i < games.length; i++ )
                {
                    try
                    {
                        var game = games[ i ];

                        var gameData = JSON.parse( game.ReplayInfoJson );

                        var processedGame = model.processReplay( gameData, game.LobbyId, game );

                        if ( !! processedGame )
                            newGameList.push( processedGame );
                    }
                    catch (e)
                    {
                        console.log('failed to parse TitleData');
                        console.error( e );
                        console.log( game.ReplayInfoJson );
                    }
                }

                model.gameList( newGameList );

                if ( ( startingGameListSize == 0 && newGameList.length != 0 ) || ( startingGameListSize != 0 && newGameList.length == 0 ) )
                    respondToResize();

            }).fail( function (data)
            {
                return;
            });
        }

        var uberId = $.url().param('uberId');

        if ( uberId )
        {
            model.otherUberId (uberId );
            model.replayListScope( uberId );

            var displayName = $.url().param( 'displayName' ) || 'Contact';

            model.otherDisplayName( displayName );
        }
    }

    ko.computed( function()
    {
       var state =
       {
           scene: 'replay_browser',
           status: 'Viewing replays',
           timestamp: Date.now()
       }
       api.Panel.message( 'uberbar', 'community_chat_state', state );
    });
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}