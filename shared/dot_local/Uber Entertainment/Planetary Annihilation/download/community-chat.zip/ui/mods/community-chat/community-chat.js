function communityChat()
{
    var self = this;

    self.socket = false;

    self.uberId = false;
    self.uberName = false;
    self.displayName = false;
    self.uberToken = false;
    self.client = false;

    self.sendAuthTimeout = false;

    self.sendAuth = function( )
    {
        console.log( 'Community Chat authenticating' );

        self.sendAuthTimeout = false;

        var client = self.client;

        self.socket.emit( 'auth', { uberId: self.uberId, uberName: self.uberName, uberToken: self.uberToken, displayName: self.displayName, client: client, version: 2, buildVersion: window.gVersion } );
    }

    self.join = function( room )
    {
        self.socket.emit( 'join', room );
    }

    self.leave = function( room )
    {
        self.socket.emit( 'leave', room );
    }

    self.sendMessage = function( room, message )
    {
        self.socket.emit( 'message', { room: room, message: message } );
    }

    self.sendInfo = function( info )
    {
        if ( ! info.uberId )
            return;

        self.socket.emit( 'info', info );
    }

    self.disconnect = function()
    {
        if ( self.socket )
        {
            self.socket.disconnect( true );
            self.socket = false;
        }
    }

    self.connect = function()
    {
console.log( 'Community Chat connect' );
        var dev = $.url().param('dev') != undefined;

        var server = dev ? 'http://127.0.0.1:8086/' : 'https://palobby.com/';

        var path = '/community-chat-server';

        var test = $.url().param('test') != undefined;

        if ( test )
            path = '/community-chat-test-server';

        if ( self.socket )
            self.socket.disconnect( true );

        var socket = self.socket = io( server, { path: path, multiplex: true, reconnect: true, reconnectDelay: 15000, reconnectDelayMax: 60000, timeout: 30000 , transports: [ 'polling', 'websocket' ] } );

        socket.on( 'disconnect', function( data)
        {
console.log( 'Community Chat disconnected' );

            if (self.sendAuthTimeout)
            {
                clearTimeout( sendAuthTimeout );
                self.sendAuthTimeout = false;
            }

            self.onDisconnected( data );
        })

        socket.on( 'connect_error', function( connect_error )
        {
console.log( 'Community Chat connect_error' );
console.error( connect_error );
        })

        socket.on( 'connect_timeout', function()
        {
console.log( 'Community Chat connect_timeout' );
        })

        socket.on( 'connect', function( data )
        {
            self.onStatus( 'Connected... authenticating' );

            if (self.sendAuthTimeout)
            {
                clearTimeout( sendAuthTimeout );
                self.sendAuthTimeout = false;
            }

            self.sendAuthTimeout = setTimeout( self.sendAuth, 1000 );
        });

        socket.on( 'reconnecting', function( reconnect_attempts  )
        {
            self.onStatus( 'Reconnecting #' + reconnect_attempts );
        });

        socket.on( 'reconnect', function( reconnect_attempts  )
        {
            self.onStatus( 'Reconnected' );
        });

        socket.on( 'reconnect_error', function( reconnect_error )
        {
            self.onStatus( 'Reconnect error ' + reconnect_error );
        });

        socket.on( 'reconnect_failed', function()
        {
console.log( 'Community Chat reconnect_failed' );
        });

        socket.on( 'banned', function( data )
        {
console.log( 'banned' );
            socket.disconnect( true );
        });

        socket.on( 'authenticated', function( data )
        {
console.log( 'Community Chat authenticated' );
            self.onReady( data );
        });

        socket.on( 'no-auth', function( data  )
        {
console.log( 'Community Chat no-auth' );
console.log( JSON.stringify( data ) );
        })

        socket.on( 'auth-failed', function( data )
        {
console.log( 'Community Chat auth-failed' );
console.log( JSON.stringify( data ) );
       })

        socket.on( 'login', function( data )
        {
        })

        socket.on( 'duplicate-login', function( data )
        {
console.log( 'Community Chat duplicate-login' );
console.log( JSON.stringify( data ) );
        })

        socket.on( 'joined', function( data )
        {
            self.onJoined( data );
        })

        socket.on( 'already-joined', function( data )
        {
console.log( 'Community Chat already-joined ' + data.room );
            self.onJoined( data );
        })

        socket.on( 'room-not-found', function( data )
        {
console.log( 'Community Chat room-not-found ' + data.room );
console.log( JSON.stringify( data ) );
        })

        socket.on( 'user-joined', function( data )
        {
            self.onUserJoined( data );
        })

        socket.on( 'user-client-joined', function( data )
        {
            self.onUserClientJoined( data );
        })

        socket.on( 'user-left', function( data )
        {
            self.onUserLeft( data );
        })

        socket.on( 'user-client-left', function( data )
        {
            self.onUserClientLeft( data );
        })

        socket.on( 'user-kicked', function( data )
        {
            self.onUserKicked( data );
        })

        socket.on( 'user-muted', function( data )
        {
            self.onUserMuted( data );
        })

        socket.on( 'user-unmuted', function( data )
        {
            self.onUserUnmuted( data );
        })

        socket.on( 'user-info', function( data )
        {
            self.onUserInfo( data );
        })

        socket.on( 'user-details', function( data )
        {
            self.onUserDetails( data );
        })

        socket.on( 'message', function( data )
        {
            self.onMessage( data );
        })

        socket.on( 'history-cleared', function( data )
        {
            self.onRoomHistoryCleared( data );
        })

        socket.on( 'bad-message', function( data )
        {
console.log( 'Community Chat bad-message ' + data.room + ' ' + data.uberId + ' ' + data.displayName );
console.log( JSON.stringify( data ) );
            self.onBadMessage( data );
        })

        socket.on( 'update-message', function( data )
        {
            self.onUpdateMessage( data );
        })

        socket.on( 'server-error', function( data )
        {
console.log( 'Community Chat server-error' );
console.log( JSON.stringify( data ) );
        })

        socket.on( 'shutdown', function( data  )
        {
            socket.disconnect( true );
        })
    }

    self.onStatus = function( data ) {};
    self.onReady = function( data ) {};
    self.onDisconnected = function( data ) {};
    self.onJoined = function( data ) {};
    self.onUserJoined = function( data ) {};
    self.onUserClientJoined = function( data ) {};
    self.onUserLeft = function( data ) {};
    self.onUserClientLeft = function( data ) {};
    self.onUserKicked = function( data ) {};
    self.onUserMuted = function( data ) {};
    self.onUserUnmuted = function( data ) {};
    self.onUserInfo = function( data ) {};
    self.onUserDetails = function( data ) {};
    self.onMessage = function( data ) {};
    self.onUpdateMessage = function( data ) {};
    self.onBadMessage = function( data ) {};
    self.onRoomHistoryCleared = function( data ) {};

    self.languages =
    {
"af": "Afrikaans",
"sq": "Albanian",
"am": "Amharic",
"ar": "Arabic",
"hy": "Armenian",
"az": "Azeerbaijani",
"eu": "Basque",
"be": "Belarusian",
"bn": "Bengali",
"bs": "Bosnian",
"bg": "Bulgarian",
"ca": "Catalan",
"ceb": "Cebuano",
"ny": "Chichewa",
"zh-CN": "Chinese (Simplified)",
"zh-TW": "Chinese (Traditional)",
"co": "Corsican",
"hr": "Croatian",
"cs": "Czech",
"da": "Danish",
"nl": "Dutch",
"en": "English",
"eo": "Esperanto",
"et": "Estonian",
"tl": "Filipino",
"fi": "Finnish",
"fr": "French",
"fy": "Frisian",
"gl": "Galician",
"ka": "Georgian",
"de": "German",
"el": "Greek",
"gu": "Gujarati",
"ht": "Haitian Creole",
"ha": "Hausa",
"haw": "Hawaiian",
"iw": "Hebrew",
"hi": "Hindi",
"hmn": "Hmong",
"hu": "Hungarian",
"is": "Icelandic",
"ig": "Igbo",
"id": "Indonesian",
"ga": "Irish",
"it": "Italian",
"ja": "Japanese",
"jw": "Javanese",
"kn": "Kannada",
"kk": "Kazakh",
"km": "Khmer",
"ko": "Korean",
"ku": "Kurdish",
"ky": "Kyrgyz",
"lo": "Lao",
"la": "Latin",
"lv": "Latvian",
"lt": "Lithuanian",
"lb": "Luxembourgish",
"mk": "Macedonian",
"mg": "Malagasy",
"ms": "Malay",
"ml": "Malayalam",
"mt": "Maltese",
"mi": "Maori",
"mr": "Marathi",
"mn": "Mongolian",
"my": "Burmese",
"ne": "Nepali",
"no": "Norwegian",
"ps": "Pashto",
"fa": "Persian",
"pl": "Polish",
"pt": "Portuguese",
"ma": "Punjabi",
"ro": "Romanian",
"ru": "Russian",
"sm": "Samoan",
"gd": "Scots Gaelic",
"sr": "Serbian",
"st": "Sesotho",
"sn": "Shona",
"sd": "Sindhi",
"si": "Sinhala",
"sk": "Slovak",
"sl": "Slovenian",
"so": "Somali",
"es": "Spanish",
"su": "Sundanese",
"sw": "Swahili",
"sv": "Swedish",
"tg": "Tajik",
"ta": "Tamil",
"te": "Telugu",
"th": "Thai",
"tr": "Turkish",
"uk": "Ukrainian",
"ur": "Urdu",
"uz": "Uzbek",
"vi": "Vietnamese",
"cy": "Welsh",
"xh": "Xhosa",
"yi": "Yiddish",
"yo": "Yoruba",
"zu": "Zulu",
    }
}

var CommunityChat = new communityChat();
