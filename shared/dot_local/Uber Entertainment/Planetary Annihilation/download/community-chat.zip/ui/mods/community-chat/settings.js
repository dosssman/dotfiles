var paChatLoaded;

function communityChat()
{
    if ( paChatLoaded )
    {
        console.log( 'Community Chat settings already loaded' );
        return;
    }

    paChatLoaded = true;

    console.log( 'Community Chat settings' );

    ko.computed( function()
    {
        if ( ! model.active() || model.inPanel() )
            return;

        var state =
        {
            scene: 'settings',
            status: 'Game settings',
            timestamp: Date.now()
        }

        api.Panel.message( 'uberbar', 'community_chat_state', state );
    });
}

try
{
    communityChat();
}
catch ( e )
{
    console.error( e );
}