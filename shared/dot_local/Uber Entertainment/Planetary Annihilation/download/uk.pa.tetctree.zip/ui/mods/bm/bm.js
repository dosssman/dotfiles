model.biomes.push('oasis', 'rainforest', 'mountain','icey')
