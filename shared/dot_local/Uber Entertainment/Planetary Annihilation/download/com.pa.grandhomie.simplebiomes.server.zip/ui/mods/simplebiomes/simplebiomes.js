model.biomes.push('sandstone', 'grass', 'arctic', 'gas_small', 'gas_yellow', 'gas_violet')
