var global_mod_list = [
    "coui://ui/mods/rfloatframe/rfloatframe.css",
    "coui://ui/mods/rfloatframe/rfloatframe.js",
    "coui://ui/mods/hotbuild2/global_mod_list/hotbuild.js"
];
var scene_mod_list = {
    "live_game": [
        "coui://ui/mods/rfloatframe/livegameprep.js",
        "coui://ui/mods/community-chat/live_game.js",
        "coui://ui/mods/hotbuild2/live_game/hotbuild_core.js",
        "coui://ui/mods/tInfiniteBuild/live_game/init.js"
    ],
    "load_planet": [
        "coui://ui/mods/system_sharing/system_sharing.js",
        "coui://ui/mods/system_sharing/load_planet.js",
        "coui://ui/mods/system_sharing/load_planet.css",
        "coui://ui/mods/community-chat/load_planet.js",
        "coui://ui/mods/com.pa.legion-expansion/load_planet.js",
        "coui://ui/mods/grandhomie/maps.js",
        "coui://ui/mods/wpmarshall/maplist.js",
        "coui://ui/mods/maps/maplist.js",
        "coui://ui/mods/tetcmp1/maplist.js",
        "coui://ui/mods/kingslayergm/maps.js"
    ],
    "start": [
        "coui://ui/mods/community-chat/start.js",
        "coui://ui/mods/com.pa.legion-expansion/start.js"
    ],
    "connect_to_game": [
        "coui://ui/mods/community-chat/connect_to_game.js"
    ],
    "matchmaking": [
        "coui://ui/mods/community-chat/matchmaking.js"
    ],
    "leaderboard": [
        "coui://ui/mods/community-chat/leaderboard.js",
        "coui://download/community-mods-leaderboard.js"
    ],
    "new_game_ladder": [
        "coui://ui/mods/community-chat/new_game_ladder.css",
        "coui://ui/mods/community-chat/new_game_ladder.js",
        "coui://ui/mods/dfavouritecolour/dfavouritecolour_new_game.js"
    ],
    "server_browser": [
        "coui://ui/mods/community-chat/server_browser.js",
        "coui://ui/mods/com.pa.legion-expansion/server_browser.js"
    ],
    "new_game": [
        "coui://ui/mods/community-chat/new_game.css",
        "coui://ui/mods/community-chat/new_game.js",
        "coui://ui/mods/com.pa.legion-expansion/new_game.js",
        "coui://ui/mods/no_default_system/no_default_system.js",
        "coui://ui/mods/dfavouritecolour/dfavouritecolour_new_game.js",
        "coui://ui/mods/community-mods-client/new_game.js"
    ],
    "replay_browser": [
        "coui://ui/mods/community-chat/replay_browser.js",
        "coui://download/community-mods-replay_browser.js"
    ],
    "system_editor": [
        "coui://ui/mods/community-chat/system_editor.js",
        "coui://ui/mods/simplebiomes/simplebiomes.js",
        "coui://ui/mods/bm/bm.js",
        "coui://download/community-mods-system_editor.js"
    ],
    "settings": [
        "coui://ui/mods/community-chat/settings.js",
        "coui://ui/mods/com.pa.legion-expansion/settings.js",
        "coui://ui/mods/hotbuild2/settings/hotbuild_settings.css",
        "coui://ui/mods/hotbuild2/settings/hotbuild_settings.js",
        "coui://ui/mods/dfavouritecolour/dfavouritecolour_settings.js"
    ],
    "uberbar": [
        "coui://ui/mods/community-chat/uberbar.css",
        "coui://ui/mods/community-chat/strophe.min.js",
        "coui://ui/mods/community-chat/jabber.js",
        "coui://ui/mods/community-chat/socket.io.slim.js",
        "coui://ui/mods/community-chat/community-chat.js",
        "coui://ui/mods/community-chat/uberbar.js"
    ],
    "live_game_options_bar": [
        "coui://ui/mods/community-chat/live_game_options_bar.css",
        "coui://ui/mods/community-chat/live_game_options_bar.js",
        "coui://ui/mods/com.pa.legion-expansion/live_game_options_bar.js"
    ],
    "shared_build": [
        "coui://ui/mods/com.pa.legion-expansion/shared_build.js"
    ],
    "live_game_players": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_players.js"
    ],
    "live_game_planets": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_planets.js"
    ],
    "live_game_control_group_bar": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_control_group_bar.js"
    ],
    "live_game_econ": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_econ.js"
    ],
    "live_game_time_bar": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_time_bar.js"
    ],
    "live_game_build_bar": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_build_bar.js",
        "coui://ui/mods/hotbuild2/live_game/hotbuild.css",
        "coui://ui/mods/hotbuild2/live_game/hotbuild_buildbar.js"
    ],
    "live_game_build_hover": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_build_hover.js"
    ],
    "live_game_action_bar": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_action_bar.js"
    ],
    "live_game_selection": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_selection.js",
        "coui://ui/mods/hotbuild2/live_game/hotbuild.css",
        "coui://ui/mods/hotbuild2/live_game/hotbuild_selection.js"
    ],
    "live_game_sandbox": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_sandbox.js"
    ],
    "live_game_menu": [
        "coui://ui/mods/com.pa.legion-expansion/live_game_menu.js"
    ],
    "LiveGame_FloatZone": [
        "coui://ui/mods/hotbuild2/live_game/hotbuild.css",
        "coui://ui/mods/hotbuild2/live_game/hotbuild_floatframe.js"
    ],
    "gw_play": [
        "coui://download/community-mods-gw_play.js"
    ],
    "game_over": [
        "coui://download/community-mods-game_over.js"
    ],
    "live_game_chat": [
        "coui://ui/mods/community-mods-client/live_game_chat.js"
    ]
};
