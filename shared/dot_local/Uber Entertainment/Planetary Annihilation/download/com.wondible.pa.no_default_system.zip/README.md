# No Default System

Stop the new game lobby from loading a system you are not going to use.

Finally you can browse your custom systems without lag.
