model.loadRandomSystem = function() {
  model.requestUpdateCheatConfig();
}
