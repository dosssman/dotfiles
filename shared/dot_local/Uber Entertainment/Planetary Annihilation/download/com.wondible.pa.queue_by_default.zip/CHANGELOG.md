# Queue By Default

## 1.1.2

- Forum url, released

## 1.1.1

- lgir namespaced

## 1.1.0

- Right click exists command mode
- Right click clears selection in command or fab mode
