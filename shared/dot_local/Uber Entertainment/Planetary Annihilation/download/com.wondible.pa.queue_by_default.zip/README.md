# Queue by Default

Build mode appends to the queue unless shift is held.

Command mode starts a new sequence, and then stays in command mode to queue additional points.  Use shift on the first click to append the new command sequence to the current queue.

This inversion of shift function is tragic and needs to be addressed.

Right click in command or fab mode clears the selection.

## Dependencies

Live Game Input Refactor
