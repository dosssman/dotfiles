var global_server_mod_list = [];
var scene_server_mod_list = {
    "new_game": [
        "coui://ui/mods/com.pa.quitch.qAIModCompatibilityPatch/new_game.js",
        "coui://ui/mods/com.pa.legion-expansion/new_game.js",
        "coui://ui/mods/com.pa.quitch.qquellerai/new_game.js"
    ],
    "icon_atlas": [
        "coui://ui/mods/com.pa.legion-expansion/icon_atlas.js"
    ],
    "system_editor": [
        "coui://ui/mods/bm/bm.js"
    ]
};
try {
    loadScript("coui://ui/mods/ui_mod_list_for_server.js");
    try { global_mod_list = _.union( global_mod_list, global_server_mod_list ) } catch (e) { console.log(e); };
    try { _.forOwn( scene_server_mod_list, function( value, key ) { if ( scene_mod_list[ key ] ) { scene_mod_list[ key ] = _.union( scene_mod_list[ key ], value ) } else { scene_mod_list[ key ] = value } } ); } catch (e) { console.log(e); }
} catch (e) { console.log(e); var global_mod_list = global_server_mod_list; var scene_mod_list = scene_server_mod_list; }
